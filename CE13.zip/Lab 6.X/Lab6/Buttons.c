// **** Include libraries here ****
// Standard libraries

//CMPE13 Support Library
#include "BOARD.h"
#include "Buttons.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries

// **** Set macros and preprocessor directives ****

// **** Declare any datatypes here ****

// **** Define global, module-level, or external variables here ****

// **** Declare function prototypes ****
//ButtonsInitialize
void ButtonsInit(void){
TRISD |= 0x00E0;
TRISF |= 0x0002;
}
//Check for Button Events
uint8_t ButtonsCheckEvents(void){
    int BUTTON_STATE_0 = 0x0;
    uint8_t buttonstate = BUTTON_STATES();
    if (buttonstate & BUTTON_STATE_1){
        return BUTTON_EVENT_1DOWN;
    } else {
        return BUTTON_EVENT_1UP;
    }
    if (buttonstate & BUTTON_STATE_2){
        return BUTTON_EVENT_2DOWN;
    } else {
        return BUTTON_EVENT_2UP;
    }
    if (buttonstate & BUTTON_STATE_3){
        return BUTTON_EVENT_3DOWN;
    } else {
        return BUTTON_EVENT_3UP;
    }
    if (buttonstate & BUTTON_STATE_4){
        return BUTTON_EVENT_4DOWN;
    } else {
        return BUTTON_EVENT_4UP;
    } 
    if (buttonstate & BUTTON_STATE_0){
        return BUTTON_EVENT_NONE;
    }
}