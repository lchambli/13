// **** Include libraries here ****
// Standard libraries

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "Leds.h"

// **** Set macros and preprocessor directives ****

// **** Declare any datatypes here ****
/*struct
should have a uint8_t member named "event" and a unsigned 8-bit
variable named "value".*/
struct TimerResult {
    uint8_t event;
    unsigned short int value;
};
// **** Define global, module-level, or external variables here ****
/*module-level variable for storing your timer event data, of type
"struct TimerResult". These will be used for persistent data storage in
the interrupt and for checking for events in main()*/
static struct TimerResult TimerResult;
/* constants LEFT (value: 1) and RIGHT (value: 0) at the top of
bounce.c and use them within your while-loop and for the direction of
your bouncing LED*/
#define LEFT 1
#define RIGHT 0

// **** Declare function prototypes ****

int main(void)
{
    BOARD_Init();

    // Configure Timer 1 using PBCLK as input. This default period will make the LEDs blink at a
    // pretty reasonable rate to start.
    OpenTimer1(T1_ON | T1_SOURCE_INT | T1_PS_1_8, 0xFFFF);

    // Set up the timer interrupt with a priority of 4.
    INTClearFlag(INT_T1);
    INTSetVectorPriority(INT_TIMER_1_VECTOR, INT_PRIORITY_LEVEL_4);
    INTSetVectorSubPriority(INT_TIMER_1_VECTOR, INT_SUB_PRIORITY_LEVEL_0);
    INTEnable(INT_T1, INT_ENABLED);

    /***************************************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     **************************************************************************************************/
    /*Given
     * initialize leds library
    while true:
        if the timer event flag is set:
            if we?re at the last LED:
                reverse direction
                trigger next LED
            else:
                trigger next LED
        clear the timer event flag*/
    unsigned short int ledsConfig, direction = LEFT;    
    LEDS_INIT();
    LEDS_SET(0x01);
    ledsConfig = (0x01);
    
//    LEDS_INIT ();
//    LEDS_SET(0x01);
//    
    while (1) {
        if (TimerResult.event == TRUE) {
            TimerResult.event = FALSE;
            if (direction == LEFT){
                LEDS_SET (ledsConfig);
                ledsConfig = ledsConfig << 1;
            }
            if (direction == RIGHT){
                LEDS_SET (ledsConfig);
                ledsConfig = ledsConfig >> 1;
            }
            if (ledsConfig == 0x80){
                direction = RIGHT;
            }
            if (ledsConfig == 0x00){
                ledsConfig = 0x01;
                direction = LEFT;
//                LEDS_SET (ledsConfig);
            }
        }
    }
//Initial Test Code
//    LEDS_INIT();
//    LEDS_SET(0xCC);
//    int i;
//    for( i = 0; i < 10000000; ++i);
//    LEDS_SET(0xDD);
//    for(i = 0; i < 10000000; ++i);
//    LEDS_SET(0);
//    for (i = 0; i < 10000000; ++i);
//    LEDS_SET(0xFF);

    while (1);
}
/***************************************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks.
     **************************************************************************************************/

/**
 * This is the interrupt for the Timer1 peripheral. During each call it increments a counter (the
 * value member of a module-level TimerResult struct). This counter is then checked against the
 * binary values of the four switches on the I/O Shield (where SW1 has a value of 1, SW2 has a value
 * of 2, etc.). If the current counter is greater than this switch value, then the event member of a
 * module-level TimerResult struct is set to true and the value member is cleared.
 */
void __ISR(_TIMER_1_VECTOR, IPL4AUTO) Timer1Handler(void)
{
    // Clear the interrupt flag.
    INTClearFlag(INT_T1);
    int switches = SWITCH_STATES();
    TimerResult.value = TimerResult.value + 1;
    if (TimerResult.value >= switches){
        TimerResult.event = TRUE;
        TimerResult.value = 0;
    }

}