// **** Include libraries here ****
// Standard libraries

//CMPE13 Support Library
#include "BOARD.h"
#include "Buttons.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries


// **** Set macros and preprocessor directives ****

// **** Declare any datatypes here ****
struct buttonreturn {
    uint8_t event;
};
// **** Define global, module-level, or external variables here ****
static struct buttonreturn buttonreturn;
// **** Declare function prototypes ****

int main(void)
{
    BOARD_Init();

    // Configure Timer 1 using PBCLK as input. This default period will make the LEDs blink at a
    // pretty reasonable rate to start.
    OpenTimer1(T1_ON | T1_SOURCE_INT | T1_PS_1_8, 0xFFFF);

    // Set up the timer interrupt with a priority of 4.
    INTClearFlag(INT_T1);
    INTSetVectorPriority(INT_TIMER_1_VECTOR, INT_PRIORITY_LEVEL_4);
    INTSetVectorSubPriority(INT_TIMER_1_VECTOR, INT_SUB_PRIORITY_LEVEL_0);
    INTEnable(INT_T1, INT_ENABLED);

    /***************************************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     **************************************************************************************************/
    /**/
    /*initialize buttons library
while true:
if a button event flag is set:
store the current switch positions
if Switch 1 is on and Button 1 up event:
toggle LD1 and LD2 LEDs in bitmask
else if Switch 1 is off and Button 1 down event:
toggle LD1 and LD2 LEDs in bitmask
if Switch 2 is on and Button 2 up event:
toggle LD3 and LD4 LEDs in bitmask
else if Switch 2 is off and Button 2 down event:
toggle LD3 and LD4 LEDs in bitmask
if Switch 3 is on and Button 3 up event:
toggle LD5 and LD6 LEDs in bitmask
else if Switch 3 is off and Button 3 down event:
toggle LD5 and LD6 LEDs in bitmask
if Switch 4 is on and Button 4 up event:
toggle LD7 and LD8 LEDs in bitmask
else if Switch 4 is off and Button 4 down event:
toggle LD7 and LD8 LEDs in bitmask
clear button event flag*/
//    while (1) {
//        
//    }


    /***************************************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks
     **************************************************************************************************/

    while (1);
}

/**
 * This is the interrupt for the Timer1 peripheral. It checks for button events and stores them in a
 * module-level variable.
 */
void __ISR(_TIMER_1_VECTOR, IPL4AUTO) Timer1Handler(void)
{
    // Clear the interrupt flag.
    INTClearFlag(INT_T1);
    if (BUTTON_EVENT_1UP || BUTTON_EVENT_1DOWN || BUTTON_EVENT_2UP ||BUTTON_EVENT_2DOWN
            || BUTTON_EVENT_3UP || BUTTON_EVENT_3DOWN || BUTTON_EVENT_4UP || BUTTON_EVENT_4DOWN) {
        buttonreturn.event = TRUE;
    }

}