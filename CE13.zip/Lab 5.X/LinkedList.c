//Lucas Chambliss
//lchambli@ucsc.edu
//SID #1356825
//CE 13  Winter 2016 Lab 5 - Linked Lists
// **** Include libraries here ****
// Standard libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "LinkedList.h"
// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****

// **** Declare function prototypes (in order of header file declarations)****
ListItem *LinkedListNew(char *data);
char *LinkedListRemove(ListItem *item);
int LinkedListSize(ListItem *list);
ListItem *LinkedListGetFirst(ListItem *list);
ListItem *LinkedListCreateAfter(ListItem *item, char *data);
int LinkedListSwapData(ListItem *firstItem, ListItem *secondItem);
int LinkedListSort(ListItem *list);
int LinkedListPrint(ListItem *list);

/****************************************************************
 Defines LinkedListNew
 ***************************************************************/
ListItem *LinkedListNew(char *data)
{
    ListItem *new = malloc(sizeof (ListItem));
    if (new) {
        new->previousItem = NULL; //head as null because no item before
        new->nextItem = NULL; //tail as null because no item after
        new->data = data; //data in LinkedList.h to go between NULLs
    }
    return new;
    if (*data == NULL) { //Pointer to data cannot be null but data can be
        printf("Error: Memory allocation failed");
        return NULL;
    }
}

/****************************************************************
 Defines LinkedListCreateAfter
 ***************************************************************/
ListItem *LinkedListCreateAfter(ListItem *item, char *data)
{
    ListItem *new = LinkedListNew(data); //this will contain the malloc
    //and null return if the memory cannot be allocated
    if (item) {
        new->nextItem = item->nextItem;
        if (new->nextItem) {
            item->nextItem->previousItem = new;
        }
        item->nextItem = new;
        new->previousItem = item;
    }
    return new;
}

/****************************************************************
 Defines LinkedListGetFirst
 ***************************************************************/
ListItem *LinkedListGetFirst(ListItem *list)
{
    if (list->previousItem != NULL) {
        return LinkedListGetFirst(list->previousItem);
    } else {
        return NULL;
    }
}

/****************************************************************
 Defines LinkedListSize
 ***************************************************************/
int LinkedListSize(ListItem *list)
{
    ListItem *new = LinkedListGetFirst(list);
    int counter = 0;
    for (; new && new->nextItem; counter++) {
        new = new->nextItem;
    }
    return (counter) ? (++counter) : (counter);
    if ((counter = NULL)) {
        return 0;
    }
}

/****************************************************************
 Defines LinkedListPrint
 ***************************************************************/
int LinkedListPrint(ListItem *list)
{
    ListItem *new = (LinkedListGetFirst(list));
    printf("\n[");
    int counter = 0;
    for (; new != NULL && new->nextItem; counter++) {
        new = new->nextItem;
        printf("new->nextItem");
    }
    printf("]\n");
    return SUCCESS;
}

/****************************************************************
 Defines LinkedListSwapData
 ***************************************************************/
int LinkedListSwapData(ListItem *firstItem, ListItem *secondItem)
{

    if ((firstItem = NULL)) {
        printf("Error: not enough items");
        return STANDARD_ERROR;
    } else if ((secondItem = NULL)) {
        printf("Error: not enough items");
        return STANDARD_ERROR;
    } else {
        char *new = firstItem->data;
        firstItem->data = secondItem->data;
        secondItem->data = new;
        return SUCCESS;
    }
}

/****************************************************************
 Defines LinkedListRemove
 ***************************************************************/
char *LinkedListRemove(ListItem *item)
{
    char *temp = item->data;
    if (item->nextItem != item->previousItem && item) {
        if (item->nextItem) {
            item->nextItem->previousItem = item->previousItem;
        }
        if (item->previousItem) {
            item->previousItem->nextItem = item->nextItem;
        }
        return temp;
    } else {
        return STANDARD_ERROR;
    }
    free(item);
}

/****************************************************************
 Defines LinkedListSort
 * Provided pseudo code:
 * 
for i = 0 to length(A) ? 2 do
for j = i + 1 to length(A) - 1 do
                     if A[j] < A[i] do
                          swap A[j] and A[i]
end if end for
end for
 ***************************************************************/
int LinkedListSort(ListItem *list)
{
    ListItem *new = LinkedListGetFirst(list);
    ListItem *temp = new;
    ListItem *next = new->nextItem;
    int counter = 0;
    for (; new != NULL && new->nextItem; counter++) {
        if (temp < next) {
            LinkedListSwapData(temp, next);
        }
    }
    return SUCCESS;
}
