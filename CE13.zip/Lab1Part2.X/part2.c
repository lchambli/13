//Lucas Chambliss, SID 1356825, lchambli@ucsc.edu [Part2.c]
// **** Include libraries here ****
// Standard libraries
#include <stdio.h>

//Class specific libraries
#include "BOARD.h"

// Microchip libraries
#include <xc.h>

// User libraries
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    BOARD_Init();
    /***************************************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     **************************************************************************************************/
    //Declare Variables
    float fahr, celsius;
    int lower, upper, step;
    //Initialize Variables
    lower = 0; //lower limit of temperature
    upper = 300; //upper limit of temperature
    step = 20; //step size
    fahr = lower;
    printf("    F   C\n"); //labels columns of output temperature units
    //Print out table
    while (fahr <= upper) {
        celsius = (5.0 / 9.0)*(fahr - 32.0);
        //degrees fahr in left column and degrees celsius in right, printf formatted by
        printf("%7.1f %04.f\n", (double) fahr, (double) celsius); 
        fahr = fahr + step;
    }
    printf("\n");
    float kelv = lower; //labels columns of output temperature units
    printf("    K   F\n");
    //Print out table
    while (kelv <= upper) {
        fahr = ((9.0 / 5.0)*(kelv - 273.0))+32.0;
        //degrees kelvin in left column and degrees fahr in right, printf formatted by
        printf("%03.3f %5.4f\n", (double) kelv, (double) fahr); 
        kelv = kelv + step;
    }

    /***************************************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks.
     **************************************************************************************************/

    // Returning from main() is bad form in embedded environments. So we sit and spin.
    while (1);
}
