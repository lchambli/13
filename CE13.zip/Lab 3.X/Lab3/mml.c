// **** Include libraries here ****
// Standard libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

//CMPE13 Support Library
#include "BOARD.h"


// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "MatrixMath.h"
// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****

// **** Declare function prototypes ****
//void MatrixMultiply(float mat1[3][3], float mat2[3][3], float result[3][3]);
//void MatrixAdd(float mat1[3][3], float mat2[3][3], float result[3][3]);
//int MatrixEquals(float mat1[3][3], float mat2[3][3]);
//void MatrixScalarMultiply(float x, float mat[3][3], float result[3][3]);
//void MatrixScalarAdd(float x, float mat[3][3], float result[3][3]);
//float MatrixDeterminant(float mat[3][3]);
//float MatrixTrace(float mat[3][3]);
//void MatrixTranspose(float mat[3][3], float result[3][3]);
//void MatrixInverse(float mat[3][3], float result[3][3]);
//void MatrixPrint(float mat[3][3]);
//

int main()
{
    BOARD_Init();

    /******************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     *****************************************************************************/
    int fPASS = 0;
    int p[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}};
    int q[3][3] = {
        {2, 4, 6},
        {8, 10, 12},
        {14, 16, 18}};
    int t[3][3] = {
        {1, 3, 5},
        {7, 9, 11},
        {13, 15, 17}};
    int r1[3][3] = {};
    int r2[3][3] = {};
    int a[3][3] = {
        {60, 72, 84},
        {132, 162, 192},
        {204, 252, 300}};
    int b[3][3] = {
        {54, 66, 78},
        {117, 147, 177},
        {180, 228, 276}};
    int c[3][3] = {
        {3, 6, 9},
        {12, 15, 18},
        {21, 24, 27}};
    int d[3][3] = {
        {2, 5, 8},
        {11, 14, 17},
        {20, 23, 26}};
    int e[3][3] = {
        {2, 3, 4},
        {5, 6, 7},
        {8, 9, 10}};
    int f[3][3] = {
        {4, 6, 8},
        {10, 12, 14},
        {16, 18, 20}};
    int g[3][3] = {
        {1, 4, 7},
        {2, 5, 8},
        {3, 6, 9}};
    int h[3][3] = {
        {2, 8, 14},
        {4, 10, 16},
        {6, 12, 18}};
    int i[3][3] = {
        {1, 0, 0},
        {0, 1, 0},
        {0, 0, 1}};
    int j[3][3] = {
        {5, 0, 0},
        {0, 5, 0},
        {0, 0, 5}};
    int k[3][3] = {
        {0.2, 0, 0},
        {0, 0.2, 0},
        {0, 0, 0.2}};

    //-------------------------------------------------------------------------
    //MATRIX EQUALITY
    int equalsPassCounter = MatrixEquals(p, p) + MatrixEquals(q, q);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixEquals()\n");
    //-------------------------------------------------------------------------
    //MATRIX ADD TEST
    MatrixAdd(p, q, r1);
    equalsPassCounter = MatrixEquals(r1, c);
    MatrixAdd(p, t, r2);
    equalsPassCounter += MatrixEquals(r2, d);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixAdd()\n");
    //-------------------------------------------------------------------------
    //MATRIX SCALAR ADD TEST
    MatrixScalarAdd(1, p, r1);
    equalsPassCounter = MatrixEquals(r1, e);
    MatrixScalarAdd(2, q, r2);
    equalsPassCounter += MatrixEquals(r2, f);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixScalarAdd()\n");
    //-------------------------------------------------------------------------
    //MATRIX SCALAR MULTIPLY TEST
    MatrixScalarMultiply(1, p, r1);
    equalsPassCounter = MatrixEquals(r1, p);
    MatrixAdd(1, q, r2);
    equalsPassCounter += MatrixEquals(r2, q);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixScalarMultiply()\n");
    //-------------------------------------------------------------------------    
    //MATRIX MULTIPLY TEST
    MatrixMultiply(p, q, r1);
    equalsPassCounter = MatrixEquals(r1, a);
    MatrixMultiply(p, t, r2);
    equalsPassCounter += MatrixEquals(r2, b);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixMultiply()\n");

    //-------------------------------------------------------------------------
    //MATRIX TRACE TEST
    //MatrixTrace (p);
    equalsPassCounter = (MatrixTrace(p) == 15.0);
    MatrixTrace(q);
    equalsPassCounter += (MatrixTrace(q) == 30.0);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixTrace()\n");
    //-------------------------------------------------------------------------
    //MATRIX DETERMINANT TEST
    //MatrixDeterminant ();
    equalsPassCounter = (MatrixDeterminant(p) == 0) + (MatrixDeterminant(q) == 0);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixDeterminant()\n");
    //-------------------------------------------------------------------------
    //MATRIX TRANSPOSE TEST
    MatrixTranspose(p, r1);
    equalsPassCounter = MatrixEquals(r1, g);
    MatrixTranspose(q, r2);
    equalsPassCounter += MatrixEquals(r2, h);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixTranspose()\n");
    //-------------------------------------------------------------------------
    //MATRIX INVERSE TEST
    MatrixInverse(i, r1);
    equalsPassCounter = MatrixEquals(r1, i);
    MatrixInverse(j, r2);
    equalsPassCounter += MatrixEquals(r2, k);
    if (equalsPassCounter == 2) {
        fPASS++;
        printf("Passed (%d/2)", equalsPassCounter);
    }
    printf("MatrixTranspose()\n");
    //-------------------------------------------------------------------------
    //MATRIX PRINT TEST
    printf("%d out of %d tests passed (%2.1f%%).\n", (double) (fPASS / 9) * 100.0);
    MatrixPrint(p);
    printf("1, 2, 3\n", "4, 5, 6\n", "7, 8, 9\n");
    /******************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks
     *****************************************************************************/

    // Returning from main() is bad form in embedded environments. So we sit and spin.
    while (1);
}

