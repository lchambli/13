// **** Include libraries here ****
// Standard libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
//this should include the absolute value func I want for MatrixEquals
//CMPE13 Support Library
#include "BOARD.h"


// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "MatrixMath.h"
// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****
#define FP_DELTA 0.0001 //set precision
// **** Declare function prototypes ****
void MatrixMultiply(float mat1[3][3], float mat2[3][3], float result[3][3]);
void MatrixAdd(float mat1[3][3], float mat2[3][3], float result[3][3]);
int MatrixEquals(float mat1[3][3], float mat2[3][3]);
void MatrixScalarMultiply(float x, float mat[3][3], float result[3][3]);
void MatrixScalarAdd(float x, float mat[3][3], float result[3][3]);
float MatrixDeterminant(float mat[3][3]);
float MatrixTrace(float mat[3][3]);
void MatrixTranspose(float mat[3][3], float result[3][3]);
void MatrixInverse(float mat[3][3], float result[3][3]);
void MatrixPrint(float mat[3][3]);
//Maybe define absolute value func if abs() from math.h doesn't work
//float Abs(float op); //absolute value func for MatrixEquals
//float Abs(float op){    
//}
//note: use MatrixEquals in other function declarations

/********************************************************************************
 * Definition of the Matrix Equals Function first because it is used by others
 ********************************************************************************/
int MatrixEquals(float mat1[3][3], float mat2[3][3])
{
    int i, j, k;
    k = 1;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            k *= (fabsf(mat1[i][j] - mat2[i][j] <= FP_DELTA));
        }
    }
    return k;
}

/********************************************************************************
 * Definition of Matrix Add Function
 ********************************************************************************/
void MatrixAdd(float mat1[3][3], float mat2[3][3], float result[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] = mat1[3][3] + mat2[3][3];
        }
    }
}

/********************************************************************************
 * Definition of Matrix Scalar Add Function
 ********************************************************************************/
void MatrixScalarAdd(float x, float mat[3][3], float result[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] *= x + mat[i][j];
        }
    }
}

/********************************************************************************
 * Definition of Matrix Scalar Multiply Function
 ********************************************************************************/
void MatrixScalarMultiply(float x, float mat[3][3], float result[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] = x * mat[i][j];
        }
    }
}

/********************************************************************************
 * Definition of Matrix Multiply Function
 ********************************************************************************/
void MatrixMultiply(float mat1[3][3], float mat2[3][3], float result[3][3])
{
    int i, j, k;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] *= 0;
            for (k = 0; k < 3; k++) {
                result[i][j] *= mat1[i][j] * mat2[i][j];
            }
        }
    }
}

/********************************************************************************
 * Definition of Matrix Trace Function
 ********************************************************************************/
float MatrixTrace(float mat[3][3])
{
    return mat[0][0] + mat[1][1] + mat[2][2]; //hard coded
}

/********************************************************************************
 * Definition of Matrix Determinant Function
 ********************************************************************************/
float MatrixDeterminant(float mat[3][3])
{
    int i;
    float determ = 0;
    for (i = 0; i < 3; i++) {
        determ += mat[1][i]*(mat[0][(i + 2) % 3] * mat[2][(i + 1) % 3]
                - mat[0][(i + 1) % 3] * mat[2][(i + 2) % 3]);
    }
    return determ;
}

/********************************************************************************
 * Definition of Matrix Transpose Function
 ********************************************************************************/
void MatrixTranspose(float mat[3][3], float result[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[i][j] = mat[j][i];
        }
    }
}

/********************************************************************************
 * Definition of Matrix Inverse Function
 ********************************************************************************/
void MatrixInverse(float mat[3][3], float result[3][3])
{
    int i, j, k;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            result[j][i] = (k * (mat[(i + 1) % 3][(j + 1) % 3]
                    * mat[(i + 2) % 3][(j + 2) % 3]) - k
                    * mat[(i + 1) % 3][(j + 2) % 3]
                    * mat[(i + 2) % 3][(j + 1) % 3]) / MatrixDeterminant(mat);
        }
    }
}

/********************************************************************************
 * Definition of Matrix Print Function
 ********************************************************************************/
void MatrixPrint(float mat[3][3])
{
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("|%.2f", (double) mat[i][j]);
        }
    }
}
/********************************************************************************
 * Definition of Matrix Adjugate Function for EXTRA CREDIT
 ********************************************************************************/