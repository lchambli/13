//Lucas Chambliss, SID 1356825, lchambli@ucsc.edu [Part3-CMath.c]
//This part was exceptionally confusing, especially in the lab manual
//include libraries
#include <stdio.h>
#include "CMath.h"
#include <stdlib.h>
//#include <math.h>
float abs(floatx); //function prototype

int main(void)
{
    BOARD_Init();

    //there is no absolute value command, so must create if statement to take abs(dx)

    float abs(float x)
    {
        if (x < 0)
            x = -(x);
        else
            x = x;
        //there is no absolute value command, so must create if statement to take abs(dy)               
        //    if ((qy-py)<0)
        //        dy=-(qy-py);
        //    else
        //        dy=(qy-py);
    }

    //start of Euclidean distance equation

    float enorm(float px, float py, float qx, float qy) 
    {
        
            int g, e, dx, dy;
            float (dx)
            float (dy)
            if (dy > dx) {
                g = dx;
                e = dy;
                else
                    g = dy;
                e = dx;
            }
            int i; //create integer i to loop for-loop twice
            int g, e, t, r, s;
            for (i = 0; i < 2; i++) {
                t = e / g;
                r = t*t;
                s = r / (4.0 + r);
                g = g + (2 * s * g);
                e = e*s;
                return g
            }
        }
    
    
    //Lets say I wanted to find the absolute value
    //of some number x
    //float x = -1;
    //x = x*5;
    //x = abs(x);
    //return(x);
    
    
    
    //start of arctangent equation
//  y= float y          
    if (x>0) {
        
    }
//            }

   
