/* 
 * File:   CMath.h
 * Author: lucaschambliss
 * SID 1356825, lchambli@ucsc.edu
 * Created on January 13, 2016, 2:56 PM
 */

#ifndef CMATH_H
#define	CMATH_H
float arctangent2(float y, float x);
float enorm(float px, float py, float qx, float qy)

#endif	/* CMATH_H */

