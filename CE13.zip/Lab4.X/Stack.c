//Lucas Chambliss
//lchambli@ucsc.edu
//SID #1356825
//CE 13  Winter 2016 Lab 4 - Reverse Polish Notation Calculator
//Stack.c
// **** Include libraries here ****
// Standard libraries
//#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
//#include <math.h>
//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
//#include <xc.h>
//#include <plib.h>

// User libraries
#include "Stack.h"
// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****
#define true 1;
// **** Declare function prototypes (in order of header file declarations)****
void StackInit(struct Stack *stack);
int StackPush(struct Stack *stack, float value);
int StackPop(struct Stack *stack, float *value);
int StackIsEmpty(const struct Stack *stack);
int StackIsFull(const struct Stack *stack);
int StackGetSize(const struct Stack *stack);
// **** Declare Funcs in order of given iterative design, but with struct first
//struct declaration from stack.h, for ref
//struct Stack {
//    float stackItems[STACK_SIZE];
//    int currentItemIndex;
//    uint8_t initialized;
//};

/****************************************************************
 Defines StackInit
 ***************************************************************/
void StackInit(struct Stack *stack)
{
    stack->currentItemIndex = -1;
    stack->initialized = true;
}

/****************************************************************
 Defines StackIsEmpty
 ***************************************************************/
int StackIsEmpty(const struct Stack *stack)
{
    return (stack->currentItemIndex == -1) && stack->initialized;
}

/****************************************************************
 Defines StackPush
 ***************************************************************/
int StackPush(struct Stack *stack, float value)
{
    if (stack->currentItemIndex++ < (STACK_SIZE - 1) && stack->initialized) {
        stack->stackItems[stack->currentItemIndex] = value;
        return SUCCESS;
    } else {
        stack->currentItemIndex--; //decrement
        return STANDARD_ERROR;
    }
}

/****************************************************************
 Defines StackIsFull
 ***************************************************************/
int StackIsFull(const struct Stack *stack)
{
    return (stack->currentItemIndex == (STACK_SIZE - 1)) && stack->initialized;
}

/****************************************************************
 Defines StackPop
 ***************************************************************/
int StackPop(struct Stack *stack, float *value)
{
    if (stack->currentItemIndex-- > -1 && stack->initialized) {
        *value = stack->stackItems[stack->currentItemIndex + 1];
        return SUCCESS;
    } else {
        stack->currentItemIndex++;
        return STANDARD_ERROR;
    }
}

/****************************************************************
 Defines StackGetSize
 ***************************************************************/
int StackGetSize(const struct Stack *stack)
{
    return (stack->currentItemIndex + 1)
            * stack->initialized + SIZE_ERROR
            * (!stack->initialized);
}