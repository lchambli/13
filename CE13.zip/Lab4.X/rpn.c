//Lucas Chambliss
//lchambli@ucsc.edu
//SID #1356825
//CE 13  Winter 2016 Lab 4 - Reverse Polish Notation Calculator
//rpn.c
// **** Include libraries here ****
// Standard libraries
//#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
//#include <math.h>
//CMPE13 Support Library
#include "BOARD.h"


// Microchip libraries
//#include <xc.h>
//#include <plib.h>


// User libraries
#include "Stack.h"

// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****
//#define true 1;
//#define NULL ((void *)1);
// **** Declare function prototypes ****
/*
 * Function prototype for ProcessBackspaces() - This function should be defined
 * below main after the related comment.
 */
//int ProcessBackspaces(char *rpn_sentence);

// If this code is used for testing, rename main to something we can call from our testing code. We
// also skip all processor configuration and initialization code.
#ifndef LAB4_TESTING

int main()
{
    BOARD_Init();
#else

int their_main(void)
{
#endif // LAB4_TESTING

    /******************************** Your custom code goes below here *******************************/
    printf("Welcome to Lucas's Reverse Polish Notation Calculator!\n");
    char x[60]; //sets input limit to string of 60 characters, to be used in fgets
    char *result = NULL;
    float a;
    float output;
    float op1, op2;
    struct Stack stack;
    while (1) { //use while loop to continuously prompt new calculations
        printf("\nEnter a series of floats and +, -, /, or * in RPN format:\n");
        StackInit(&stack);
        //uses fgets as recommended in manual, and sets input limit to 60 floats
        //stack size is still only 20 though, but that is because operands
        //will not be loaded into the stack so they aren't a part of the 60 spots
        fgets(x, 60, stdin);
        result = strtok(x, " ");
        while (result != NULL) {
            // atof converts the string into a double and assigns it to new float a
            a = atof(result);
            if (a || *result == '0') {
                if (!StackIsFull(&stack)) {
                    StackPush(&stack, a);
                } else {
                    printf("Error, stack full.\n");
                    break;
                }
            }//start of character checking to operate on two previous
                //float operands in order of what's declared in the manual
            else if (*result == '+' || *result == '-' || *result == '/' || *result == '*') {
                if (*result == '+' && StackGetSize(&stack) > 1) {
                    StackPop(&stack, &op1);
                    StackPop(&stack, &op2);
                    StackPush(&stack, op2 + op1);
                } else if (*result == '-' && StackGetSize(&stack) > 1) {
                    StackPop(&stack, &op1);
                    StackPop(&stack, &op2);
                    StackPush(&stack, op2 - op1);
                } else if (*result == '/' && StackGetSize(&stack) > 1) {
                    StackPop(&stack, &op1);
                    StackPop(&stack, &op2);
                    StackPush(&stack, op2 / op1);
                } else if (*result == '*' && StackGetSize(&stack) > 1) {
                    StackPop(&stack, &op1);
                    StackPop(&stack, &op2);
                    StackPush(&stack, op2 * op1);
                }//error to be printed when only operators entered by user, or
                    //when there are some operands but too many operators to handle
                else {
                    printf("ERROR, more operands needed to perform operation.\n");
                    break;
                }
            } else {
                printf("ERROR, invalid character. Enter +, -, *, or / only.\n");
                break;
            }
            //strtok splits string elements into token components
            result = strtok(NULL, " ");
            if (result == NULL) {
                if (StackGetSize(&stack) == 1) {
                    StackPop(&stack, &output);
                    printf("%f", (double) output);
                    break;
                } else {
                    printf("ERROR Invalid calculation\n");
                    break;
                }

            }
        }

    }

    /*************************************************************************************************/

    // You can never return from main() in an embedded system (one that lacks an operating system).
    // This will result in the processor restarting, which is almost certainly not what you want!
    while (1);
}

/**
 * Extra Credit: Define ProcessBackspaces() here - This function should read through an array of
 * characters and when a backspace character is read it should replace the preceding character with
 * the following character. It should be able to handle multiple repeated backspaces and also
 * strings with more backspaces than characters. It should be able to handle strings that are at
 * least 256 characters in length.
 * @param rpn_sentence The string that will be processed for backspaces. This string is modified in
 *                     place.
 * @return Returns the size of the resultant string in `rpn_sentence`.
 */
//int ProcessBackspaces(char *rpn_sentence) {
//    return 0;
//}



