/*Lucas Chambliss, SID 1356825, lchambli@ucsc.edu [Part0.c]
 * File:   Part0.c
 * Author: lucaschambliss
 *
 * Created on January 12, 2016, 12:52 AM
 */


#include "xc.h"

int main(void) 
{
    BOARD_Init();
    printf("HelloWorld\n");
    while(1);
}
