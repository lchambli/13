//Lucas Chambliss - CE13 Winter 2016
//lchambli@ucsc.edu
//
// **** Include libraries here ****
// Standard libraries

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

//User libraries
#include "Oled.h"
#include "Ascii.h"
#include "OledDriver.h"
#include "Buttons.h"
#include "Leds.h"
#include "Adc.h"

// **** Set any macros or preprocessor directives here ****
// Set a macro for resetting the timers, makes the code a little clearer.
#define TIMER_2HZ_RESET() (TMR1 = 0)
#define TIMER_5HZ_RESET() (TMR)
#define LONG_PRESS = 5

// **** Declare any datatypes here ****

struct OvenData {
    int CountPause;
    int CountTimer;
    int TimeLeftMin; //countdown timer for cooking
    int TimeLeftSec; //
    int InitTimeMin; //Start time, to be set and counted down from
    int InitTimeSec; //Start time, to be set and counted down from
    int CookTemp; //Temperature to cook at, only changes in oven mode
    int CookMode; //bake, toast, or broil modes
    int OvenState; //which parts of the oven are on
    int ButtPressCount; //counter for buttons 1-4
    int InputSel; //whether the pot selects time or temp
    int CountLED;
    int Mult;
    int OverallInitTime;
    int OverallFinalTime;
};
// **** Define any module-level, global, or external variables here ****
static struct OvenData OvenData;
static uint8_t ButtonFlag;
static int Mask = 0;

enum {
    BAKE = 0x00, TOAST = 0x01, BROIL = 0x02, TIME_CHANGE = 0x03,
    TEMP_CHANGE = 0x04, COUNTDOWN = 0x05, PENDING_SELECTOR_CHANGE = 0x06,
    PENDING_RESET = 0x07, START = 0x08, RESET = 0x09
};
// Configuration Bit settings

int main()
{
    BOARD_Init();

    // Configure Timer 1 using PBCLK as input. We configure it using a 1:256 prescalar, so each timer
    // tick is actually at F_PB / 256 Hz, so setting PR1 to F_PB / 256 / 2 yields a 0.5s timer.
    OpenTimer1(T1_ON | T1_SOURCE_INT | T1_PS_1_256, BOARD_GetPBClock() / 256 / 2);

    // Set up the timer interrupt with a medium priority of 4.
    INTClearFlag(INT_T1);
    INTSetVectorPriority(INT_TIMER_1_VECTOR, INT_PRIORITY_LEVEL_4);
    INTSetVectorSubPriority(INT_TIMER_1_VECTOR, INT_SUB_PRIORITY_LEVEL_0);
    INTEnable(INT_T1, INT_ENABLED);

    // Configure Timer 2 using PBCLK as input. We configure it using a 1:16 prescalar, so each timer
    // tick is actually at F_PB / 16 Hz, so setting PR2 to F_PB / 16 / 100 yields a .01s timer.
    OpenTimer2(T2_ON | T2_SOURCE_INT | T2_PS_1_16, BOARD_GetPBClock() / 16 / 100);

    // Set up the timer interrupt with a medium priority of 4.
    INTClearFlag(INT_T2);
    INTSetVectorPriority(INT_TIMER_2_VECTOR, INT_PRIORITY_LEVEL_4);
    INTSetVectorSubPriority(INT_TIMER_2_VECTOR, INT_SUB_PRIORITY_LEVEL_0);
    INTEnable(INT_T2, INT_ENABLED);

    // Configure Timer 3 using PBCLK as input. We configure it using a 1:256 prescalar, so each timer
    // tick is actually at F_PB / 256 Hz, so setting PR3 to F_PB / 256 / 5 yields a .2s timer.
    OpenTimer3(T3_ON | T3_SOURCE_INT | T3_PS_1_256, BOARD_GetPBClock() / 256 / 5);

    // Set up the timer interrupt with a medium priority of 4.
    INTClearFlag(INT_T3);
    INTSetVectorPriority(INT_TIMER_3_VECTOR, INT_PRIORITY_LEVEL_4);
    INTSetVectorSubPriority(INT_TIMER_3_VECTOR, INT_SUB_PRIORITY_LEVEL_0);
    INTEnable(INT_T3, INT_ENABLED);

    /***************************************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     **************************************************************************************************/
    OledInit();
    LEDS_INIT();
    ButtonsInit();
    AdcInit();
    int Counter1 = 3;
    char TestingString [60], TimeArrowSel = ' ', TempArrowSel = ' ';
    OvenData.CookMode = BAKE;
    OvenData.OvenState = RESET;
    OvenData.InputSel = TIME_CHANGE;
    OvenData.TimeLeftSec = 1;
    OvenData.TimeLeftMin = 1;
    while (1) {
        switch (OvenData.OvenState) {
            /***********************************RESET*************************************
             *************************************CASE*************************************/
        case RESET:
            OvenData.CookMode = BAKE;
            OvenData.CookTemp = 350;
            OvenData.InitTimeSec = 01;
            OvenData.InitTimeMin = 0;
            OvenData.InputSel = TIME_CHANGE;
            OvenData.OvenState = START;
            Mask = 0;
            LEDS_SET(Mask);
            TimeArrowSel = '>';
            TempArrowSel = ' ';
            OledClear(OLED_COLOR_BLACK);
            sprintf(TestingString, "|     |  Mode: Bake\n"
                    "|     |  %cTime: %d:%02d\n"
                    "|-----|  %cTemp: %d%cF\n"
                    "|     |", TimeArrowSel,
                    OvenData.InitTimeMin, OvenData.InitTimeSec, TempArrowSel,
                    OvenData.CookTemp, 0xF8);
            OledDrawString(TestingString);
            for (Counter1 = 3; Counter1 < 38; Counter1++) {
                OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
            }
            for (Counter1 = 2; Counter1 < 39; Counter1++) {
                OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
            }
            OledUpdate();
            break;
            /***********************************START**************************************
             *************************************CASE*************************************/
        case (START):
            OvenData.CountPause = 0;
            LEDS_SET(0);
            OledClear(OLED_COLOR_BLACK);
            OledSetDisplayNormal();

            if ((ButtonFlag & BUTTON_EVENT_3DOWN)) {

                ButtonFlag = 0;
                OvenData.ButtPressCount = 0;
                OvenData.OvenState = PENDING_SELECTOR_CHANGE;
                break;
            }
            if (ButtonFlag & BUTTON_EVENT_4DOWN) {

                IFS0CLR = 1 << 12;
                ButtonFlag = 0;
                OvenData.TimeLeftSec = OvenData.InitTimeSec;
                OvenData.TimeLeftMin = OvenData.InitTimeMin;
                OvenData.OverallInitTime = (OvenData.InitTimeSec + (OvenData.InitTimeMin) * 60.0);
                Mask = 0xFF;
                OvenData.Mult = 8.0;
                OvenData.CountLED = 9;
                OvenData.OvenState = COUNTDOWN;
                break;
            }
            //****************************************************************************
            //BAKEMODE                
            if (OvenData.CookMode == BAKE) {
                if (OvenData.InputSel == TIME_CHANGE) {
                    OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                    OvenData.InitTimeSec = AdcRead() / 4 - (OvenData.InitTimeMin * 60) + 1;
                }
                if (OvenData.InputSel == TEMP_CHANGE) {
                    OvenData.CookTemp = (AdcRead() >> 2) + 300;
                }
                if (OvenData.InputSel == TIME_CHANGE) {
                    TimeArrowSel = '>';
                    TempArrowSel = ' ';
                }
                if (OvenData.InputSel == TEMP_CHANGE) {
                    TimeArrowSel = ' ';
                    TempArrowSel = '>';
                }
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|     |  Mode: Bake\n"
                        "|     | %cTime: %d:%02d\n"
                        "|-----| %cTemp: %d%cF\n"
                        "|     |", TimeArrowSel,
                        OvenData.InitTimeMin, OvenData.InitTimeSec, TempArrowSel,
                        OvenData.CookTemp, 0xF8);
                OledDrawString(TestingString);
                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
                if (AdcChanged() == TRUE) {
                    OvenData.CookTemp = 350;
                    if (OvenData.InputSel == TIME_CHANGE) {
                        OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                        OvenData.InitTimeSec = AdcRead() / 4 - (OvenData.InitTimeMin * 60) + 1;
                    }
                    if (OvenData.InputSel == TEMP_CHANGE) {
                        OvenData.CookTemp = (AdcRead() >> 2) + 300;
                    }
                    if (OvenData.InputSel == TIME_CHANGE) {
                        TimeArrowSel = '>';
                        TempArrowSel = ' ';
                    }
                    if (OvenData.InputSel == TEMP_CHANGE) {
                        TempArrowSel = '>';
                        TimeArrowSel = ' ';
                    }
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|     |  Mode: Bake\n"
                            "|     | %cTime: %d:%02d\n"
                            "|-----| %cTemp: %d%cF\n"
                            "|     |", TimeArrowSel,
                            OvenData.InitTimeMin, OvenData.InitTimeSec, TempArrowSel,
                            OvenData.CookTemp, 0xF8);
                    OledDrawString(TestingString);
                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                    OledUpdate();
                    break;
                }
            }
            //****************************************************************************
            //TOASTMODE                
            if (OvenData.CookMode == TOAST) {

                OvenData.CookTemp = 500;
                OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                OvenData.InitTimeSec = AdcRead() / 4 - (OvenData.InitTimeMin * 60) + 1;
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|     |  Mode: Toast\n"
                        "|     |  Time: %d:%02d\n"
                        "|-----|  \n"
                        "|     |", OvenData.InitTimeMin,
                        OvenData.InitTimeSec);
                OledDrawString(TestingString);

                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
                OvenData.InputSel = TIME_CHANGE;
                OledClear(OLED_COLOR_BLACK);
                if (AdcChanged() == TRUE) {
                    OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                    OvenData.TimeLeftSec = AdcRead() / 4 - (OvenData.TimeLeftMin * 60) + 1;
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|     |  Mode: Toast\n"
                            "|     |  Time: %d:%02d\n"
                            "|-----|  \n"
                            "|     |", OvenData.InitTimeMin,
                            OvenData.InitTimeSec);
                    OledDrawString(TestingString);

                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                    OledUpdate();
                    break;
                }
            }
            //*****************************************************************************
            //BROILMODE                
            if (OvenData.CookMode == BROIL) {
                OvenData.CookTemp = 500;
                OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                OvenData.InitTimeSec = AdcRead() / 4 - (OvenData.InitTimeMin * 60) + 1;
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|     |  Mode: Broil\n"
                        "|     |  Time: %d:%02d\n"
                        "|-----|  Temp: %d%cF\n"
                        "|     |", OvenData.InitTimeMin, OvenData.InitTimeSec,
                        OvenData.CookTemp, 0xF8);
                OledDrawString(TestingString);

                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
                OvenData.InputSel = TIME_CHANGE;
                TimeArrowSel = '>';
                if (AdcChanged() == TRUE) {
                    OvenData.CookTemp = 500;
                    OvenData.InitTimeMin = (AdcRead() / 4) / 60;
                    OvenData.InitTimeSec = AdcRead() / 4 - (OvenData.InitTimeMin * 60) + 1;
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|     |  Mode: Broil\n"
                            "|     |  Time: %d:%02d\n"
                            "|-----|  Temp: %d%cF\n"
                            "|     |", OvenData.InitTimeMin, OvenData.InitTimeSec,
                            OvenData.CookTemp, 0xF8);
                    OledDrawString(TestingString);

                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                }
            }
            OledClear(OLED_COLOR_BLACK);
            break;
        case (COUNTDOWN):
            OvenData.OverallFinalTime = (OvenData.TimeLeftSec + ((OvenData.TimeLeftMin) * 60.0));

            if (((OvenData.OverallFinalTime) - ((OvenData.OverallInitTime / 8.0) * OvenData.Mult)) < .9
                    && (OvenData.OverallFinalTime) - ((OvenData.OverallInitTime / 8.0) * OvenData.Mult) > -.9) {

                (OvenData.Mult)--;
                if (OvenData.CountLED < 9) {
                    Mask = Mask << 1;
                }
                --(OvenData.CountLED);
            }
            LEDS_SET(Mask);
            if ((ButtonFlag & BUTTON_EVENT_4DOWN)) {

                IFS0CLR = 1 << 12;
                ButtonFlag = 0;
                OvenData.ButtPressCount = 0;
                OvenData.OvenState = PENDING_RESET;
                break;
            }
            if (OvenData.CookMode == BAKE) {
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|*****|  Mode: Bake\n"
                        "|     |  Time: %d:%02d\n"
                        "|-----|  Temp: %d%cF\n"
                        "|*****|", OvenData.TimeLeftMin,
                        OvenData.TimeLeftSec,
                        OvenData.CookTemp, 0xF8);
                OledDrawString(TestingString);

                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
            }

            if (OvenData.CookMode == TOAST) {
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|     |  Mode: Toast\n"
                        "|     |  Time: %d:%02d\n"
                        "|-----|  \n"
                        "|*****|", OvenData.TimeLeftMin,
                        OvenData.TimeLeftSec);
                OledDrawString(TestingString);

                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
            }
            if (OvenData.CookMode == BROIL) {
                OledClear(OLED_COLOR_BLACK);
                sprintf(TestingString,
                        "|*****|  Mode: Broil\n"
                        "|     |  Time: %d:%02d\n"
                        "|-----|  Temp: %d%cF\n"
                        "|     |", OvenData.TimeLeftMin,
                        OvenData.TimeLeftSec,
                        OvenData.CookTemp, 0xF8);

                OledDrawString(TestingString);

                for (Counter1 = 3; Counter1 < 38; Counter1++) {
                    OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                }
                for (Counter1 = 2; Counter1 < 39; Counter1++) {
                    OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                }
                OledUpdate();
                break;
            }
            /***********************************PEND RES***********************************
             *************************************SELECT***********************************/
        case (PENDING_SELECTOR_CHANGE):
            if (((ButtonFlag & BUTTON_EVENT_3UP)) && OvenData.ButtPressCount < 5) {
                ButtonFlag = 0;
                ++OvenData.CookMode;
                if (OvenData.CookMode == 0x03) {
                    OvenData.CookMode = 0x00;
                }
                OvenData.OvenState = START;
            } else if (OvenData.ButtPressCount >= 5) {
                ButtonFlag = 0;
                if (OvenData.InputSel == TEMP_CHANGE) {
                    OvenData.InputSel = TIME_CHANGE;
                } else {
                    OvenData.InputSel = TEMP_CHANGE;
                }
                OvenData.OvenState = START;
            }
            break;
            /***********************************PEND**************************************
             *************************************RES*************************************/
        case (PENDING_RESET):
            if (!(ButtonFlag & BUTTON_EVENT_4UP)) {
                OvenData.OverallFinalTime = (OvenData.TimeLeftSec + ((OvenData.TimeLeftMin) * 60.0));

                if ((OvenData.OverallFinalTime - ((OvenData.OverallInitTime / 8.0) * OvenData.Mult) < .9)
                        && (OvenData.OverallFinalTime - ((OvenData.OverallInitTime / 8.0) * OvenData.Mult) > -.9)) {

                    (OvenData.Mult)--;
                    if (OvenData.CountLED < 9) {
                        Mask = Mask << 1;
                    }
                    --(OvenData.CountLED);
                }
                LEDS_SET(Mask);
                if (OvenData.CookMode == BAKE) {
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|*****|  Mode: Bake\n"
                            "|     |  Time: %d:%02d\n"
                            "|-----|  Temp: %d%cF\n"
                            "|*****|", OvenData.TimeLeftMin,
                            OvenData.TimeLeftSec,
                            OvenData.CookTemp, 0xF8);
                    OledDrawString(TestingString);

                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                    OledUpdate();
                    break;
                }

                if (OvenData.CookMode == TOAST) {
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|     |  Mode: Toast\n"
                            "|     |  Time: %d:%02d\n"
                            "|-----|  \n"
                            "|*****|", OvenData.TimeLeftMin,
                            OvenData.TimeLeftSec);
                    OledDrawString(TestingString);

                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                    OledUpdate();
                    break;
                }
                if (OvenData.CookMode == BROIL) {
                    OledClear(OLED_COLOR_BLACK);
                    sprintf(TestingString,
                            "|*****|  Mode: Broil\n"
                            "|     |  Time: %d:%02d\n"
                            "|-----|  Temp: %d%cF\n"
                            "|     |", OvenData.TimeLeftMin,
                            OvenData.TimeLeftSec,
                            OvenData.CookTemp, 0xF8);

                    OledDrawString(TestingString);

                    for (Counter1 = 3; Counter1 < 38; Counter1++) {
                        OledSetPixel(Counter1, 0, OLED_COLOR_WHITE);
                    }
                    for (Counter1 = 2; Counter1 < 39; Counter1++) {
                        OledSetPixel(Counter1, 31, OLED_COLOR_WHITE);
                    }
                    OledUpdate();
                    break;
                }
            }
            if (((ButtonFlag & BUTTON_EVENT_4UP)) && OvenData.ButtPressCount < 1) {
                OvenData.OvenState = COUNTDOWN;
                break;

            }
            if (((ButtonFlag & BUTTON_EVENT_4UP)) && OvenData.ButtPressCount >= 1) {
                ButtonFlag = 0;
                OvenData.OvenState = START;
            }
            break;
        }
    }

    /***************************************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks
     **************************************************************************************************/
    while (1);
}
//for primary time

void __ISR(_TIMER_1_VECTOR, ipl4auto) TimerInterrupt2Hz(void)
{
    // Clear the interrupt flag.
    IFS0CLR = 1 << 4;
    if ((OvenData.OvenState == COUNTDOWN || OvenData.OvenState == PENDING_RESET) && (
            OvenData.TimeLeftMin > 0 || OvenData.InitTimeSec > 0)) {
        (OvenData.CountTimer)++;
        if (OvenData.CountTimer == 2) {
            OvenData.TimeLeftSec = OvenData.TimeLeftSec - 0.5;
            OvenData.CountTimer = 0;
        }
        if (OvenData.TimeLeftSec == 0) {
            if (OvenData.TimeLeftMin == 0) {
                (OvenData.CountPause)++;
            }
            if (OvenData.CountPause < 1) {
                OvenData.TimeLeftMin -= 1;
                OvenData.TimeLeftSec = 59;
                IFS0CLR = 1 << 4;
            }
        }
    }
}
//for tracking how long the buttons are held down only

void __ISR(_TIMER_3_VECTOR, ipl4auto) TimerInterrupt5Hz(void)
{
    // Clear the interrupt flag.
    IFS0CLR = 1 << 12;
    if (OvenData.ButtPressCount < UINT8_MAX) {
        (OvenData.ButtPressCount)++;
    }
}
//for checking button events only

void __ISR(_TIMER_2_VECTOR, ipl4auto) TimerInterrupt100Hz(void)
{
    // Clear the interrupt flag.
    IFS0CLR = 1 << 8;
    ButtonFlag = ButtonsCheckEvents();
}