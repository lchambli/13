//Lucas Chambliss
//Player.c
// **** Include libraries here ****
// Standard libraries
#include <string.h>
#include <math.h>
#include <stdio.h>

//CMPE13 Support Library
#include "UnixBOARD.h"



// User libraries
#include "Game.h"
#include "Player.h"
#include "UnixBoard.h"

// **** Set any macros or preprocessor directives here ****

// **** Declare any data types here ****

// **** Define any global or external variables here ****
char playerinventory[INVENTORY_SIZE];
// **** Declare any function prototypes here ****

/**
 * Adds the specified item to the player's inventory if the inventory isn't full.
 * @param item The item number to be stored: valid values are 0-255.
 * @return SUCCESS if the item was added, STANDARD_ERRROR if the item couldn't be added.
 */
int AddToInventory(uint8_t item) {
    if ((item && INVENTORY_SIZE) > (strlen(playerinventory))) {
        strncat(playerinventory, &item, 7);
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}

/**
 * Check if the given item exists in the player's inventory.
 * @param item The number of the item to be searched for: valid values are 0-255.
 * @return SUCCESS if it was found or STANDARD_ERROR if it wasn't.
 */
int FindInInventory(uint8_t item) {
    if (strchr(playerinventory, item)) {
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}