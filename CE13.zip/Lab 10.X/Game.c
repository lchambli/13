//Lucas Chambliss
//Game.c
// **** Include libraries here ****
// Standard libraries
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
//#include <fcnt1.h>
//CMPE13 Support Library
#include "UnixBOARD.h"

// User libraries
#include "Game.h"
#include "Player.h"
#include "UnixBoard.h"

// **** Set any macros or preprocessor directives here ****

// **** Declare any data types here ****

// **** Define any global or external variables here ****
//#define ROOMFILE "RoomFiles/room%u.txt"

typedef struct {
    char title[GAME_MAX_ROOM_TITLE_LENGTH + 1];
    char description[GAME_MAX_ROOM_DESC_LENGTH + 1];
    int state;
    FILE* currentRoom;
    int roomNumber;
    uint8_t roomNorth;
    uint8_t roomEast;
    uint8_t roomSouth;
    uint8_t roomWest;

} GameStruct;

typedef enum {
    FILETITLE,
    ITEMCHECK,
    ITEMREQ,
    ITEMX,
    ITEMCONT,
    DESCRIPTION,
    EXITS,
    NOITEMREQ
} State;

static GameStruct gameData = {
    {},
    {}, FILETITLE
};
// **** Declare any function prototypes here ****
static int LoadRoom (void);
/**
 * These function transitions between rooms. Each call should return SUCCESS if the current room has
 * an exit in the correct direction and the new room was able to be loaded, and STANDARD_ERROR
 * otherwise.
 * @return SUCCESS if the room CAN be navigated to and changing the current room to that new room
 *         succeeded.
 */
//it was suggested in class that we create a LoadRoom helper function
static int LoadRoom(FILE* roomFile) {
    gameData.state = FILETITLE;
    gameData.roomNorth = 0;
    gameData.roomEast = 0;
    gameData.roomSouth = 0;
    gameData.roomWest = 0;

    while (1) {
        switch (gameData.state) {
            case FILETITLE:
                uint8_t tempLen = 0;
                char tempArray[GAME_MAX_ROOM_DESC_LENGTH + 1] = {};
                tempLen = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                if (fread(&gameData.title, sizeof (char), tempLen, roomFile) != tempLen) {
                    return STANDARD_ERROR;
                }
                gameData.state = ITEMCHECK;
                break;

            case ITEMCHECK:
                tempLen = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                gameData.state = tempLen == 0 ? DESCRIPTION : ITEMREQ;
                break;

            case ITEMREQ:
                uint8_t itemCount = 0, item = 0;
                while (itemCount < tempLen) {
                    fread(tempArray, sizeof (uint8_t), 1, roomFile);
                    item = (uint8_t) * tempArray;
                    if (FindInInventory(item) == SUCCESS) {
                        itemCount++;
                    } else {
                        itemCount++;
                        gameData.state = ITEMX;
                        break;
                    }
                    break;
                }
                if ((itemCount == tempLen) && (gameData.state != ITEMX)) {
                    gameData.state = DESCRIPTION;
                } else if ((gameData.state == ITEMX)) {
                    break;
                } else {
                    return STANDARD_ERROR;
                }
                break;

            case ITEMX:
                tempLen = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                if (fread(tempArray, sizeof (char), tempLen, roomFile) != tempLen) {
                    return STANDARD_ERROR;
                }

                tempLen = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                if (fread(tempArray, sizeof (char), tempLen, roomFile) != tempLen) {
                    return STANDARD_ERROR;
                }
                tempLen = 0;
                if (fread(tempArray, sizeof (uint8_t), 4, roomFile) != 4) {
                    return STANDARD_ERROR;
                }
                gameData.state = ITEMCHECK;
                break;

            case DESCRIPTION:
                tempLen = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                if (fread(gameData.description, sizeof (char), tempLen, roomFile) != tempLen) {
                    return STANDARD_ERROR;
                }
                gameData.state = ITEMCONT;
                break;

            case ITEMCONT:
                itemCount = 0, item = 0;
                if (fread(&tempLen, sizeof (uint8_t), 1, roomFile) != 1) {
                    return SIZE_ERROR;
                }
                while (itemCount < tempLen) {
                    fread(tempArray, sizeof (uint8_t), 1, roomFile);
                    item = (uint8_t) * tempArray;
                    if (AddToInventory(item) == SUCCESS) {
                        itemCount++;
                    } else {
                        return STANDARD_ERROR;
                        break;
                    }
                    break;
                }
                gameData.state = EXITS;
                break;

            case EXITS:
                fread(&(gameData.roomNorth), sizeof (uint8_t), 1, roomFile);
                fread(&(gameData.roomEast), sizeof (uint8_t), 1, roomFile);
                fread(&(gameData.roomSouth), sizeof (uint8_t), 1, roomFile);
                fread(&(gameData.roomWest), sizeof (uint8_t), 1, roomFile);
                return SUCCESS;
                break;
        }
    }
}

int GameGoNorth(void) {
    uint8_t exitFlags = 0;
    exitFlags = GameGetCurrentRoomExits();
    if (exitFlags & GAME_ROOM_EXIT_NORTH_EXISTS) {
        LoadRoom(gameData.currentRoom);
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}

int GameGoEast(void) {
    uint8_t exitFlags = 0;
    exitFlags = GameGetCurrentRoomExits();
    if (exitFlags & GAME_ROOM_EXIT_EAST_EXISTS) {
        LoadRoom(gameData.currentRoom);
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}

int GameGoSouth(void) {
    uint8_t exitFlags = 0;
    exitFlags = GameGetCurrentRoomExits();
    if (exitFlags & GAME_ROOM_EXIT_SOUTH_EXISTS) {
        LoadRoom(gameData.currentRoom);
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}

int GameGoWest(void) {
    uint8_t exitFlags = 0;
    exitFlags = GameGetCurrentRoomExits();
    if (exitFlags & GAME_ROOM_EXIT_WEST_EXISTS) {
        LoadRoom(gameData.currentRoom);
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }
}

/**
 * This function sets up anything that needs to happen at the start of the game. This is just
 * setting the current room to STARTING_ROOM and loading it. It should return SUCCESS if it succeeds
 * and STANDARD_ERROR if it doesn't.
 * @return SUCCESS or STANDARD_ERROR
 */
int GameInit(void) {
    char roomFileName[15];
    int startingRoom = STARTING_ROOM;
    gameData.roomNumber = STARTING_ROOM;
    sprintf(roomFileName, "RoomFiles/room%u.txt", startingRoom);
    gameData.currentRoom = fopen(roomFileName, "rb");
    LoadRoom(gameData.currentRoom);
    if (gameData.currentRoom) {
        return SUCCESS;
    } else {
        return STANDARD_ERROR;
    }

}

/**
 * Copies the current room title as a NULL-terminated string into the provided character array.
 * Only a NULL-character is copied if there was an error so that the resultant output string
 * length is 0.
 * @param title A character array to copy the room title into. Should be GAME_MAX_ROOM_TITLE_LENGTH+1
 *             in length in order to allow for all possible titles to be copied into it.
 * @return The length of the string stored into `title`. Note that the actual number of chars
 *         written into `title` will be this value + 1 to account for the NULL terminating
 *         character.
 */
int GameGetCurrentRoomTitle(char *title) {
    int x = 0;
    strcpy(title, gameData.title);
    x = strlen(gameData.title);
    return x;
}

/**
 * GetCurrentRoomDescription() copies the description of the current room into the argument desc as
 * a C-style string with a NULL-terminating character. The room description is guaranteed to be less
 * -than-or-equal to GAME_MAX_ROOM_DESC_LENGTH characters, so the provided argument must be at least
 * GAME_MAX_ROOM_DESC_LENGTH + 1 characters long. Only a NULL-character is copied if there was an
 * error so that the resultant output string length is 0.
 * @param desc A character array to copy the room description into.
 * @return The length of the string stored into `desc`. Note that the actual number of chars
 *          written into `desc` will be this value + 1 to account for the NULL terminating
 *          character.
 */
int GameGetCurrentRoomDescription(char *desc) {
    int x = 0;
    strcpy(desc, gameData.description);
    x = strlen(gameData.description);
    return x;
}

/**
 * This function returns the exits from the current room in the lowest-four bits of the returned
 * uint8 in the order of NORTH, EAST, SOUTH, and WEST such that NORTH is in the MSB and WEST is in
 * the LSB. A bit value of 1 corresponds to there being a valid exit in that direction and a bit
 * value of 0 corresponds to there being no exit in that direction. The GameRoomExitFlags enum
 * provides bit-flags for checking the return value.
 *
 * @see GameRoomExitFlags
 *
 * @return a 4-bit bitfield signifying which exits are available to this room.
 */
uint8_t GameGetCurrentRoomExits(void) {
    uint8_t exits = 0;

    if (gameData.roomNorth) {
        exits |= GAME_ROOM_EXIT_NORTH_EXISTS;
    }

    if (gameData.roomEast) {
        exits |= GAME_ROOM_EXIT_EAST_EXISTS;
    }

    if (gameData.roomSouth) {
        exits |= GAME_ROOM_EXIT_SOUTH_EXISTS;
    }

    if (gameData.roomWest) {
        exits |= GAME_ROOM_EXIT_WEST_EXISTS;
    }

    return exits;
}