//Written by Lucas Chambliss
// **** Include libraries here ****
// Standard libraries
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
#include <ctype.h>

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "Agent.h"
#include "CircularBuffer.h"
#include "Leds.h"
#include "Oled.h"
#include "Buttons.h"
#include "Protocol.h"
#include "Uart1.h"
#include "Field.h"
#include "OledDriver.h"
#include "FieldOled.h"
FieldPosition oldP;

void FieldInit(Field *f, FieldPosition p)
{
    f->hugeBoatLives = FIELD_BOAT_LIVES_HUGE;
    f->largeBoatLives = FIELD_BOAT_LIVES_LARGE;
    f->mediumBoatLives = FIELD_BOAT_LIVES_MEDIUM;
    f->smallBoatLives = FIELD_BOAT_LIVES_SMALL;

    int i = 0;
    int j = 0;
    while (i < FIELD_ROWS) {
        while (j < FIELD_COLS) {
            f->field[i][j] = p;
            j = j + 1;
        }
        j = 0;
        i = i + 1;
    }
}

FieldPosition FieldAt(const Field *f, uint8_t row, uint8_t col)
{

    if ((row < FIELD_ROWS) && (row >= 0) && (col < FIELD_COLS) && (col >= 0)) {
        return f->field[row][col];
    } else {
        return STANDARD_ERROR;
    }
}

FieldPosition FieldSetLocation(Field *f, uint8_t row, uint8_t col, FieldPosition p)
{
    //originally had a state machine here but declared oldP instead to return
    oldP = (f->field[row][col]);
    f->field[row][col] = p;
    return oldP;
}

uint8_t FieldAddBoat(Field *f, uint8_t row, uint8_t col, BoatDirection dir, BoatType type)
{
    int tempSize = 0;
    int tempRow = 0;
    int boatSize = 0;
    int boatCursor = 0;
    //type based on size of the boat
    if (((row + 1) > FIELD_ROWS) || ((col + 1) > FIELD_COLS)) {
        return STANDARD_ERROR;
    }

    switch (type) {
    case FIELD_BOAT_HUGE:
        boatSize = 6;
        boatCursor = FIELD_POSITION_HUGE_BOAT;
        break;
    case FIELD_BOAT_LARGE:
        boatSize = 5;
        boatCursor = FIELD_POSITION_LARGE_BOAT;
        break;
    case FIELD_BOAT_MEDIUM:
        boatSize = 4;
        boatCursor = FIELD_POSITION_MEDIUM_BOAT;
        break;
    case FIELD_BOAT_SMALL:
        boatSize = 3;
        boatCursor = FIELD_POSITION_SMALL_BOAT;
        break;
    }
    //makes sure the space is available

    if (dir == FIELD_BOAT_DIRECTION_NORTH) {
        if ((row + 1) - boatSize >= 0) {
            tempRow = row;
            tempSize = boatSize;
            while (tempSize > 0) {
                if (f->field[tempRow][col] == FIELD_POSITION_EMPTY) {
                    tempRow--;
                } else {
                    return STANDARD_ERROR;
                }
                tempSize--;
            }
            while (boatSize > 0) {
                f->field[row][col] = boatCursor;
                row--;
                boatSize--;
            }
        } else {
            return STANDARD_ERROR;
        }
    } else if (dir == FIELD_BOAT_DIRECTION_EAST) {
        if ((col + 1) + boatSize <= FIELD_COLS) {
            tempRow = col;
            tempSize = boatSize;
            while (tempSize > 0) {
                if (f->field[row][tempRow] == FIELD_POSITION_EMPTY) {
                    tempRow++;
                } else {
                    return STANDARD_ERROR;
                }
                tempSize--;
            }
            while (boatSize > 0) {
                f->field[row][col] = boatCursor;
                col++;
                boatSize--;
            }
        } else {
            return STANDARD_ERROR;
        }
    } else if (dir == FIELD_BOAT_DIRECTION_SOUTH) {
        if ((row + 1) + boatSize <= FIELD_ROWS) {
            tempRow = row;
            tempSize = boatSize;
            while (tempSize > 0) {
                if (f->field[tempRow][col] == FIELD_POSITION_EMPTY) {
                    tempRow++;
                } else {
                    return STANDARD_ERROR;
                }
                tempSize--;
            }
            while (boatSize > 0) {
                f->field[row][col] = boatCursor;
                row++;
                boatSize--;
            }
        } else {
            return STANDARD_ERROR;
        }
    } else if (dir == FIELD_BOAT_DIRECTION_WEST) {
        if ((col + 1) - boatSize >= 0) {
            tempRow = col;
            tempSize = boatSize;
            while (tempSize > 0) {
                if (f->field[row][tempRow] == FIELD_POSITION_EMPTY) {
                    tempRow--;
                } else {
                    return STANDARD_ERROR;
                }
                tempSize--;
            }
            while (boatSize > 0) {
                f->field[row][col] = boatCursor;
                col--;
                boatSize--;
            }
        } else {
            return STANDARD_ERROR;
        }
    } else {
        return STANDARD_ERROR;
    }
    return SUCCESS;
}

FieldPosition FieldRegisterEnemyAttack(Field *f, GuessData *gData)
{
    switch (f->field[gData->row][gData->col]) {
    case FIELD_POSITION_HUGE_BOAT:
        if (f->hugeBoatLives > 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->hugeBoatLives -= 1;
            return FIELD_POSITION_HUGE_BOAT;
            break;
        } else if (f->hugeBoatLives == 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->hugeBoatLives -= 1;
            return FIELD_POSITION_HUGE_BOAT;
            break;
        }

    case FIELD_POSITION_LARGE_BOAT:
        if (f->largeBoatLives > 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->largeBoatLives -= 1;
            return FIELD_POSITION_LARGE_BOAT;
            break;
        } else if (f->largeBoatLives == 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->largeBoatLives -= 1;
            return FIELD_POSITION_LARGE_BOAT;
            break;
        }

    case FIELD_POSITION_MEDIUM_BOAT:
        if (f->mediumBoatLives > 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->mediumBoatLives -= 1;
            return FIELD_POSITION_MEDIUM_BOAT;
            break;
        } else if (f->mediumBoatLives == 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->mediumBoatLives -= 1;
            return FIELD_POSITION_MEDIUM_BOAT;
            break;
        }

    case FIELD_POSITION_SMALL_BOAT:
        if (f->smallBoatLives > 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->smallBoatLives -= 1;
            return FIELD_POSITION_SMALL_BOAT;
            break;
        } else if (f->smallBoatLives == 1) {
            gData->hit = HIT_HIT;
            f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
            f->smallBoatLives -= 1;
            return FIELD_POSITION_SMALL_BOAT;
            break;
        }
    case FIELD_POSITION_EMPTY:
        gData->hit = HIT_MISS;
        f->field[gData->row][gData->col] = FIELD_POSITION_MISS;
        return FIELD_POSITION_EMPTY;
        break;
    }
    return (0);
}

FieldPosition FieldUpdateKnowledge(Field *f, const GuessData *gData)
{
    int pastloc = 0;
    f->field[gData->row][gData->col] = pastloc;
    if (gData->hit == HIT_HIT) {
        f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
    } else if (gData->hit == HIT_SUNK_HUGE_BOAT) {
        f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
        f->hugeBoatLives = 0;
    } else if (gData->hit == HIT_SUNK_LARGE_BOAT) {
        f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
        f->largeBoatLives = 0;
    } else if (gData->hit == HIT_SUNK_MEDIUM_BOAT) {
        f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
        f->mediumBoatLives = 0;
    } else if (gData->hit == HIT_SUNK_MEDIUM_BOAT) {
        f->field[gData->row][gData->col] = FIELD_POSITION_HIT;
        f->mediumBoatLives = 0;
    } else if (gData->hit == HIT_MISS) {
        f->field[gData->row][gData->col] = FIELD_POSITION_EMPTY;
    //We were originally returning MISS, but EMPTY was what we needed
    }
    return pastloc;
}

uint8_t FieldGetBoatStates(const Field *f)
{
    int boatstillalive = (FIELD_BOAT_STATUS_HUGE | FIELD_BOAT_STATUS_LARGE |
            FIELD_BOAT_STATUS_MEDIUM | FIELD_BOAT_STATUS_SMALL);
    if (f->hugeBoatLives == 0) {
        boatstillalive ^= FIELD_BOAT_STATUS_HUGE;
    }
    if (f->largeBoatLives == 0) {
        boatstillalive ^= FIELD_BOAT_STATUS_LARGE;
    }
    if (f->mediumBoatLives == 0) {
        boatstillalive ^= FIELD_BOAT_STATUS_MEDIUM;
    }
    if (f->smallBoatLives == 0) {
        boatstillalive ^= FIELD_BOAT_STATUS_SMALL;
    }
    return boatstillalive;
}