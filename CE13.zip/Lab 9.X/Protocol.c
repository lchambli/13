//Written by Alex Martin-Ginnold
#include "Protocol.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "BOARD.h"

static char validHex[24] = "0123456789ABCDEFabcdef";
static uint8_t hexValue;
static size_t valid;
static uint8_t atouint(const char asciiHex);
static uint32_t atodecint(const char *asciiHex);
static uint8_t getChecksum(char *checkString);
static ProtocolParserStatus checkValidity(char *checkString);
static uint8_t calculatedChecksum;
static ProtocolParserStatus messageType;
static uint8_t encodedChecksum;
static uint8_t checksum;
static uint32_t tempHash;

char encodedMessage[PROTOCOL_MAX_PAYLOAD_LEN];

typedef enum {
    WAITING,
    RECORDING,
    FIRST_CHECKSUM_HALF,
    SECOND_CHECKSUM_HALF,
    NEWLINE
} MachineStates;

struct DecodedData {
    char protocolMessage[PROTOCOL_MAX_PAYLOAD_LEN];
    int messageIndex;
    MachineStates decodeState;
    uint8_t checksum;
};

struct DecodedData protocolDecodeData;

int ProtocolEncodeCooMessage(char *message, const GuessData *data)
{

    sprintf(encodedMessage, PAYLOAD_TEMPLATE_COO, data->row, data->col);
    encodedChecksum &= 0;
    encodedChecksum = getChecksum(encodedMessage);
    sprintf(message, MESSAGE_TEMPLATE, encodedMessage, encodedChecksum);

}

int ProtocolEncodeHitMessage(char *message, const GuessData *data)
{
    sprintf(encodedMessage, PAYLOAD_TEMPLATE_HIT, data->row, data->col, data->hit);
    encodedChecksum &= 0;
    encodedChecksum = getChecksum(encodedMessage);
    sprintf(message, MESSAGE_TEMPLATE, encodedMessage, encodedChecksum);
}

int ProtocolEncodeChaMessage(char *message, const NegotiationData *data)
{
    sprintf(encodedMessage, PAYLOAD_TEMPLATE_CHA, data->encryptedGuess, data->hash);
    encodedChecksum &= 0;
    encodedChecksum = getChecksum(encodedMessage);
    sprintf(message, MESSAGE_TEMPLATE, encodedMessage, encodedChecksum);
}

int ProtocolEncodeDetMessage(char *message, const NegotiationData *data)
{
    sprintf(encodedMessage, PAYLOAD_TEMPLATE_DET, data->guess, data->encryptionKey);
    encodedChecksum &= 0;
    encodedChecksum = getChecksum(encodedMessage);
    sprintf(message, MESSAGE_TEMPLATE, encodedMessage, encodedChecksum);
}

ProtocolParserStatus ProtocolDecode(char in, NegotiationData *nData, GuessData *gData)
{

    //    protocolDecodeData = (struct DecodedData *) malloc(sizeof (struct DecodedData));
    switch (protocolDecodeData.decodeState) {
    case WAITING:
        if (in == '$') {
            protocolDecodeData.decodeState = RECORDING;
            protocolDecodeData.messageIndex = 0;
            return PROTOCOL_PARSING_GOOD;
        }

        return PROTOCOL_WAITING;
    case RECORDING:
        if (in == '*') {
            protocolDecodeData.decodeState = FIRST_CHECKSUM_HALF;
            printf("\n");
            return PROTOCOL_PARSING_GOOD;
        }
        printf("%c", in);
        protocolDecodeData.protocolMessage[protocolDecodeData.messageIndex] = in;
        protocolDecodeData.messageIndex++;


        return PROTOCOL_PARSING_GOOD;

    case FIRST_CHECKSUM_HALF:
        
        valid = strspn(&in, validHex);
        if (valid != 1) {
            protocolDecodeData.decodeState = WAITING;
            return PROTOCOL_PARSING_FAILURE;

        }
        hexValue = atouint(in);
        protocolDecodeData.checksum &= 0;
        protocolDecodeData.checksum = hexValue << 4;
        protocolDecodeData.decodeState = SECOND_CHECKSUM_HALF;
        printf("Checksum1\n");
        return PROTOCOL_PARSING_GOOD;

    case SECOND_CHECKSUM_HALF:
        valid = strspn(&in, validHex);
        if (valid != 1) {
            protocolDecodeData.decodeState = WAITING;
            return PROTOCOL_PARSING_FAILURE;

        }
        hexValue = atouint(in);
        protocolDecodeData.checksum = protocolDecodeData.checksum | hexValue;
        protocolDecodeData.protocolMessage[protocolDecodeData.messageIndex] = '\0';
        calculatedChecksum = getChecksum(protocolDecodeData.protocolMessage);

        if (protocolDecodeData.checksum == calculatedChecksum) {
            
            protocolDecodeData.decodeState = NEWLINE;
            printf("Checksum2 Pass\n");
            protocolDecodeData.protocolMessage[protocolDecodeData.messageIndex] = '\0';
            return PROTOCOL_PARSING_GOOD;
        }

        protocolDecodeData.decodeState = WAITING;
        printf("Checksum2 Fail %X, %X\n", protocolDecodeData.checksum, calculatedChecksum);
        return PROTOCOL_PARSING_FAILURE;

    case NEWLINE:

        protocolDecodeData.decodeState = WAITING;

        if (in != 10) { // 10 is the decimal value of the ascii line break
            return PROTOCOL_PARSING_FAILURE;
        }

        messageType = checkValidity(protocolDecodeData.protocolMessage);
        static const char comma[] = ",";
        static char *ret;
        ret = strpbrk(protocolDecodeData.protocolMessage, comma);
        switch (messageType) {
        case PROTOCOL_PARSED_DET_MESSAGE:
            nData->guess = atodecint(++ret);
            ret = strpbrk(ret, comma);
            nData->encryptionKey = atodecint(++ret);
            printf("detparsed\n");
            break;
        case PROTOCOL_PARSED_COO_MESSAGE:
            gData->row = atodecint(++ret);
            ret = strpbrk(ret, comma);
            gData->col = atodecint(++ret);
            printf("cooparsed\n");
            break;
        case PROTOCOL_PARSED_HIT_MESSAGE:
            gData->row = atodecint(++ret);
            ret = strpbrk(ret, comma);
            gData->col = atodecint(++ret);
            ret = strpbrk(ret, comma);
            gData->hit = atodecint(++ret);
            printf("Hitparsed\n");
            break;
        case PROTOCOL_PARSED_CHA_MESSAGE:
            nData->encryptedGuess = atodecint(++ret);
            ret = strpbrk(ret, comma);
            nData->hash = atodecint(++ret);
            printf("chaparsed\n");
            break;
        case PROTOCOL_PARSING_FAILURE:
            printf("Failure");
            break;

        }

        return messageType;

    }
}

static uint8_t atouint(const char asciiHex)
{
    static char *ptr; // An pointer used a an input to the strtol function
    return strtol(&asciiHex, &ptr, 16);


}

static uint32_t atodecint(const char *asciiNum)
{
    static char *ptr; // An pointer used a an input to the strtol function
    return strtol(asciiNum, &ptr, 10);


}

static uint8_t getChecksum(char *checkString)
{
    checksum = 0;

    while (*checkString) {
        checksum ^= *checkString++;
    }

    return checksum;
}

static ProtocolParserStatus checkValidity(char *checkString)
{
    static int numberMatching;
    numberMatching = strspn(checkString, PAYLOAD_TEMPLATE_DET);
    if (numberMatching >= 3) {
        return PROTOCOL_PARSED_DET_MESSAGE;
    }
    numberMatching = strspn(checkString, PAYLOAD_TEMPLATE_COO);
    if (numberMatching >= 3) {
        return PROTOCOL_PARSED_COO_MESSAGE;
    }
    numberMatching = strspn(checkString, PAYLOAD_TEMPLATE_HIT);
    if (numberMatching >= 3) {
        return PROTOCOL_PARSED_HIT_MESSAGE;
    }
    numberMatching = strspn(checkString, PAYLOAD_TEMPLATE_CHA);
    if (numberMatching >= 3) {
        return PROTOCOL_PARSED_CHA_MESSAGE;
    }

    return PROTOCOL_PARSING_FAILURE;
}

/**
 * This function generates all of the data necessary for the negotiation process used to determine
 * the player that goes first. It relies on the pseudo-random functionality built into the standard
 * library. The output is stored in the passed NegotiationData struct. The negotiation data is
 * generated by creating two random 16-bit numbers, one for the actual guess and another for an
 * encryptionKey used for encrypting the data. The 'encryptedGuess' is generated with an
 * XOR(guess, encryptionKey). The hash is simply an 8-bit value that is the XOR() of all of the
 * bytes making up both the guess and the encryptionKey. There is no checking for NULL pointers
 * within this function.
 * @param data The struct used for both input and output of negotiation data.
 */
void ProtocolGenerateNegotiationData(NegotiationData *data)
{
    data->encryptionKey = rand() & 65535;
    data->guess = rand() & 65535;
    data->encryptedGuess = data->encryptionKey ^ data->guess;
    data->hash = (data->guess & 0xFF) ^ (data->encryptionKey & 0xFF) ^ 
                (data->guess >> 8) ^ (data->encryptionKey >> 8);
        
}

/**
 * Validates that the negotiation data within 'data' is correct according to the algorithm given in
 * GenerateNegotitateData(). Used for verifying another agent's supplied negotiation data. There is
 * no checking for NULL pointers within this function. Returns TRUE if the NegotiationData struct
 * is valid or FALSE on failure.
 * @param data A filled NegotiationData struct that will be validated.
 * @return TRUE if the NegotiationData struct is consistent and FALSE otherwise.
 */
uint8_t ProtocolValidateNegotiationData(const NegotiationData *data)
{
    if (data->encryptedGuess != (data->encryptionKey ^ data->guess)) {
        return FALSE;
    }
    tempHash = (data->guess & 0xFF) ^ (data->encryptionKey & 0xFF) ^ 
              (data->guess >> 8) ^ (data->encryptionKey >> 8);
    if (data->hash != tempHash) {
        return FALSE;
        
    }
    
    return TRUE;
}

/**
 * This function returns a TurnOrder enum type representing which agent has won precedence for going
 * first. The value returned relates to the agent whose data is in the 'myData' variable. The turn
 * ordering algorithm relies on the XOR() of the 'encryptionKey' used by both agents. The least-
 * significant bit of XOR(myData.encryptionKey, oppData.encryptionKey) is checked so that if it's a
 * 1 the player with the largest 'guess' goes first otherwise if it's a 0, the agent with the
 * smallest 'guess' goes first. The return value of TURN_ORDER_START indicates that 'myData' won,
 * TURN_ORDER_DEFER indicates that 'oppData' won, otherwise a tie is indicated with TURN_ORDER_TIE.
 * There is no checking for NULL pointers within this function.
 * @param myData The negotiation data representing the current agent.
 * @param oppData The negotiation data representing the opposing agent.
 * @return A value from the TurnOrdering enum representing which agent should go first.
 */
TurnOrder ProtocolGetTurnOrder(const NegotiationData *myData, const NegotiationData *oppData)
{
    
    if (((myData->encryptionKey ^ oppData->encryptionKey) & 1) == 1) {
//        printf("First\n");
        if ((myData->guess) > (oppData->guess)) {
//            printf("4 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_START;
        } else if ((myData->guess) < (oppData->guess)) {
//            printf("5 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_DEFER;
        } else {
//            printf("6 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_TIE;
        }
    } else {
//        printf("last");
        if ((myData->guess) > (oppData->guess)) {
//            printf("1 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_DEFER;
        } else if ((myData->guess) < (oppData->guess)) {
//            printf("2 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_START;
        } else {
//            printf("3 %i, %i\n", myData->guess, oppData->guess);
            return TURN_ORDER_TIE;
        }
    }
}