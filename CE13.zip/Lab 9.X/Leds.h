/* 
 * File:   Leds.h
 * Author: Lucas Chambliss, lchambli@ucsc.edu, SID #1356825
 *
 * Created on February 15, 2016, 9:03 PM
 */

#ifndef LEDS_H
#define	LEDS_H

#include "BOARD.h"
#include <xc.h>

/*sets the TRISE and LATE registers
to 0. See the section here on macros and implement this in do-while
form. Don't add a semicolon at the end of this macro*/
#define LEDS_INIT() do{\
TRISE = 0; \
LATE = 0; \
}while (0)
/*returns the value of the LATE
register. Don't add a semicolon within the macro*/
#define LEDS_GET() do{\
return LATE; \
}while (0)
/*sets the LATE register to x. Be
sure to surround x in parenthesis in the macro. Also, don't add a
semicolon within the macro*/
#define LEDS_SET(x) do{\
LATE = (x); \
}while (0)


#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* LEDS_H */

