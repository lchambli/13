//written by Lucas CHambliss and Alex Martin Ginnold
#include "Agent.h"
#include "Protocol.h"
#include "Field.h"
#include "FieldOled.h"
#include "Oled.h"
#include <stdio.h>
#include "BOARD.h"
//struct GameBoard {
//    AgentState machineState;
//    Field myField;
//    Field oppField;
//};

AgentState machineState;
Field myField;
Field oppField;
FieldOledTurn whichTurn;

int rowGuess;
int colGuess;
int guessValue;

NegotiationData myNegData;
NegotiationData oppNegData;
GuessData myGuessData;
GuessData oppGuessData;

TurnOrder startingTurn;
ProtocolParserStatus parsedMessageType;

typedef enum {
    RANDOM,
    ROW_GUESS_UP,
    ROW_GUESS_DOWN,
    COL_GUESS_LEFT,
    COL_GUESS_RIGHT

} GuessType;

GuessType lastGuess;

/**
 * The Init() function for an Agent sets up everything necessary for an agent before the game
 * starts. This can include things like initialization of the field, placement of the boats,
 * etc. The agent can assume that stdlib's rand() function has been seeded properly in order to
 * use it safely within.
 */
void AgentInit(void)
{
    machineState = AGENT_STATE_GENERATE_NEG_DATA;

    whichTurn = FIELD_OLED_TURN_NONE;

    FieldInit(&myField, FIELD_POSITION_EMPTY);
    FieldInit(&oppField, FIELD_POSITION_UNKNOWN);
    static int boatPlaced;
    static int row;
    static int col;
    static int direction;
    do {
        direction = rand() & 3;
        row = rand() & 7;
        col = rand() & 15;
        boatPlaced = FieldAddBoat(&myField, row, col, direction, FIELD_BOAT_LARGE);
    } while (boatPlaced == STANDARD_ERROR);
    do {
        direction = rand() & 3;
        row = rand() & 7;
        col = rand() & 15;
        boatPlaced = FieldAddBoat(&myField, row, col, direction, FIELD_BOAT_MEDIUM);
    } while (boatPlaced == STANDARD_ERROR);
    do {
        direction = rand() & 3;
        row = rand() & 7;
        col = rand() & 15;
        boatPlaced = FieldAddBoat(&myField, row, col, direction, FIELD_BOAT_HUGE);
    } while (boatPlaced == STANDARD_ERROR);
    do {
        direction = rand() & 3;
        row = rand() & 7;
        col = rand() & 15;
        boatPlaced = FieldAddBoat(&myField, row, col, direction, FIELD_BOAT_SMALL);
    } while (boatPlaced == STANDARD_ERROR);

    FieldOledDrawScreen(&myField, &oppField, whichTurn);

}

/**
 * The Run() function for an Agent takes in a single character. It then waits until enough
 * data is read that it can decode it as a full sentence via the Protocol interface. This data
 * is processed with any output returned via 'outBuffer', which is guaranteed to be 255
 * characters in length to allow for any valid NMEA0183 messages. The return value should be
 * the number of characters stored into 'outBuffer': so a 0 is both a perfectly valid output and
 * means a successful run.
 * @param in The next character in the incoming message stream.
 * @param outBuffer A string that should be transmit to the other agent. NULL if there is no
 *                  data.
 * @return The length of the string pointed to by outBuffer (excludes \0 character).
 */
int AgentRun(char in, char *outBuffer)
{
    if ((machineState == AGENT_STATE_INVALID) ||
            (machineState == AGENT_STATE_LOST) ||
            (machineState == AGENT_STATE_WON)) {
        return 0;
    }
    int i;
    switch (machineState) {
    case AGENT_STATE_GENERATE_NEG_DATA:
        ProtocolGenerateNegotiationData(&myNegData);
        machineState = AGENT_STATE_SEND_CHALLENGE_DATA;
        int i;
        for (i = 0; i < 1000000; ++i);
        ProtocolEncodeChaMessage(outBuffer, &myNegData);
        return strlen(outBuffer);
        break;
    case AGENT_STATE_SEND_CHALLENGE_DATA:
//                OledDrawString("Fucker");
                OledUpdate();
        parsedMessageType = ProtocolDecode(in, &oppNegData, &oppGuessData);
        if (parsedMessageType == PROTOCOL_PARSED_CHA_MESSAGE) {
            ProtocolEncodeDetMessage(outBuffer, &myNegData);
            machineState = AGENT_STATE_DETERMINE_TURN_ORDER;
            return strlen(outBuffer);
        } else if (parsedMessageType == PROTOCOL_PARSING_FAILURE) {
            machineState = AGENT_STATE_INVALID;
            OledClear(OLED_COLOR_BLACK);
            OledDrawString(AGENT_ERROR_STRING_PARSING);
            OledUpdate();
            break;
        } else {
            return 0;
        }
        break;
    case AGENT_STATE_DETERMINE_TURN_ORDER:
//                OledDrawString("Cock");
                OledUpdate();
        parsedMessageType = ProtocolDecode(in, &oppNegData, &oppGuessData);
        if (parsedMessageType == PROTOCOL_PARSED_DET_MESSAGE) {
//                        OledDrawString("Shit me");
                        OledUpdate();
            if (ProtocolValidateNegotiationData(&oppNegData) == TRUE) {
                startingTurn = ProtocolGetTurnOrder(&myNegData, &oppNegData);
                switch (startingTurn) {
                case TURN_ORDER_START:
                    machineState = AGENT_STATE_SEND_GUESS;
                    whichTurn = FIELD_OLED_TURN_MINE;
                    FieldOledDrawScreen(&myField, &oppField, whichTurn);
                    break;
                case TURN_ORDER_DEFER:
                    machineState = AGENT_STATE_WAIT_FOR_GUESS;
                    whichTurn = FIELD_OLED_TURN_THEIRS;
                    FieldOledDrawScreen(&myField, &oppField, whichTurn);
                    break;
                case TURN_ORDER_TIE:
                    machineState = AGENT_STATE_INVALID;
                    OledClear(OLED_COLOR_BLACK);
                    OledDrawString(AGENT_ERROR_STRING_NEG_DATA);
                    OledUpdate();
                    break;
                }
            } else {
                machineState = AGENT_STATE_INVALID;
                OledClear(OLED_COLOR_BLACK);
                OledDrawString(AGENT_ERROR_STRING_ORDERING);
                OledUpdate();
            }
        } else if (parsedMessageType == PROTOCOL_PARSING_FAILURE) {
            machineState = AGENT_STATE_INVALID;
            OledClear(OLED_COLOR_BLACK);
            OledDrawString(AGENT_ERROR_STRING_PARSING);
            OledUpdate();
            break;
        } else {
            return 0;
        }
        break;
    case AGENT_STATE_SEND_GUESS:
        if (myGuessData.hit == HIT_HIT) {
            rowGuess = myGuessData.row;
            colGuess = myGuessData.col;
            switch (lastGuess) {
            case RANDOM:
                colGuess--;
                lastGuess = COL_GUESS_LEFT;
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (colGuess < 0)) {
                    colGuess++;
                    rowGuess--;
                    lastGuess = ROW_GUESS_UP;
                }
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (rowGuess < 0)) {
                    colGuess++;
                    rowGuess++;
                    lastGuess = COL_GUESS_RIGHT;
                }
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (colGuess >= FIELD_COLS)) {
                    colGuess--;
                    rowGuess++;
                    lastGuess = ROW_GUESS_DOWN;
                }
                break;
            case ROW_GUESS_UP:
                rowGuess--;
                lastGuess = ROW_GUESS_UP;
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (rowGuess < 0)) {
                    rowGuess += 2;
                    lastGuess = ROW_GUESS_DOWN;
                }
                break;
            case ROW_GUESS_DOWN:
                rowGuess++;
                lastGuess = ROW_GUESS_DOWN;
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (rowGuess >= FIELD_ROWS)) {
                    rowGuess -= 2;
                    lastGuess = ROW_GUESS_UP;
                }
                break;
            case COL_GUESS_LEFT:
                colGuess--;
                lastGuess = COL_GUESS_LEFT;
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (colGuess < 0)) {
                    colGuess += 2;
                    lastGuess = COL_GUESS_RIGHT;
                }
                break;
            case COL_GUESS_RIGHT:
                colGuess++;
                lastGuess = COL_GUESS_RIGHT;
                if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                        (colGuess >= FIELD_COLS)) {
                    colGuess -= 2;
                    lastGuess = COL_GUESS_LEFT;
                }
                break;
            }
            if ((FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN) ||
                    (rowGuess >= FIELD_ROWS) || (colGuess >= FIELD_COLS) ||
                    (rowGuess < 0) || (colGuess < 0)) {
                do {
                    do {
                        rowGuess = rand() & 7;
                    } while (rowGuess >= FIELD_ROWS);

                    do {
                        colGuess = rand() & 15;
                    } while (colGuess >= FIELD_COLS);

                } while (FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN);
                lastGuess = RANDOM;
            }
        } else {
            do {
                do {
                    rowGuess = rand() & 7;
                } while (rowGuess >= FIELD_ROWS);

                do {
                    colGuess = rand() & 15;
                } while (colGuess >= FIELD_COLS);

            } while (FieldAt(&oppField, rowGuess, colGuess) != FIELD_POSITION_UNKNOWN);
            lastGuess = RANDOM;
        }

        myGuessData.row = rowGuess;
        myGuessData.col = colGuess;
        for (i=0;i < (BOARD_GetPBClock() / 8); ++i);
        ProtocolEncodeCooMessage(outBuffer, &myGuessData);
        machineState = AGENT_STATE_WAIT_FOR_HIT;
        return strlen(outBuffer);
        break;
    case AGENT_STATE_WAIT_FOR_HIT:
        parsedMessageType = ProtocolDecode(in, &oppNegData, &myGuessData);
        if (parsedMessageType == PROTOCOL_PARSED_HIT_MESSAGE) {
            OledDrawString("");
            OledUpdate();
            FieldUpdateKnowledge(&oppField, &myGuessData);
            if (AgentGetEnemyStatus == 0) {
                machineState = AGENT_STATE_WON;
                whichTurn = FIELD_OLED_TURN_NONE;
            } else {
                machineState = AGENT_STATE_WAIT_FOR_GUESS;
                whichTurn = FIELD_OLED_TURN_THEIRS;
            }
            FieldOledDrawScreen(&myField, &oppField, whichTurn);
        } else if (parsedMessageType == PROTOCOL_PARSING_FAILURE) {
            machineState = AGENT_STATE_INVALID;
            OledClear(OLED_COLOR_BLACK);
            OledDrawString(AGENT_ERROR_STRING_PARSING);
            OledUpdate();
            break;
        } else {
            OledDrawString("");
            OledUpdate();
        }
        return 0;
        break;
    case AGENT_STATE_WAIT_FOR_GUESS:
        parsedMessageType = ProtocolDecode(in, &oppNegData, &oppGuessData);
        if (parsedMessageType == PROTOCOL_PARSED_COO_MESSAGE) {

            FieldRegisterEnemyAttack(&myField, &oppGuessData);

            ProtocolEncodeHitMessage(outBuffer, &oppGuessData);
            if (AgentGetStatus() == 0) {
//                printf("LOST!\n");
                machineState = AGENT_STATE_LOST;
                whichTurn = FIELD_OLED_TURN_NONE;
            } else {
                machineState = AGENT_STATE_SEND_GUESS;
                whichTurn = FIELD_OLED_TURN_MINE;
            }
            FieldOledDrawScreen(&myField, &oppField, whichTurn);
            return strlen(outBuffer);

        } else if (parsedMessageType == PROTOCOL_PARSING_FAILURE) {
            machineState = AGENT_STATE_INVALID;
            OledClear(OLED_COLOR_BLACK);
            OledDrawString(AGENT_ERROR_STRING_PARSING);
            OledUpdate();
            break;
        }
        OledDrawString("");
        OledUpdate();
        break;
    }

    return 0;
}

/**
 * StateCheck() returns a 4-bit number indicating the status of that agent's ships. The smallest
 * ship, the 3-length one, is indicated by the 0th bit, the medium-length ship (4 tiles) is the
 * 1st bit, etc. until the 3rd bit is the biggest (6-tile) ship. This function is used within
 * main() to update the LEDs displaying each agents' ship status. This function is similar to
 * Field::FieldGetBoatStates().
 * @return A bitfield indicating the sunk/unsunk status of each ship under this agent's control.
 *
 * @see Field.h:FieldGetBoatStates()
 * @see Field.h:BoatStatus
 */
uint8_t AgentGetStatus(void)
{
    return FieldGetBoatStates(&myField);
}

/**
 * This function returns the same data as `AgentCheckState()`, but for the enemy agent.
 * @return A bitfield indicating the sunk/unsunk status of each ship under the enemy agent's
 *         control.
 *
 * @see Field.h:FieldGetBoatStates()
 * @see Field.h:BoatStatus
 */
uint8_t AgentGetEnemyStatus(void)
{
    return FieldGetBoatStates(&oppField);

}