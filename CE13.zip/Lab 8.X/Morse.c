//Lucas Chambliss, lchambli@ucsc.edu
// **** Include libraries here ****
// Standard C libraries
//Battle Boats Lab Partner Alex Martin-Ginnold

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>


// User libraries
#include "Tree.h"
#include "Morse.h"
#include "Buttons.h"

// **** Set any macros or preprocessor directives here ****
// Specify a bit mask for setting/clearing the pin corresponding to BTN4. Should only be used when
// unit testing the Morse event checker.

// **** Declare any data types here ****

// **** Define any module-level, global, or external variables here ****

//binary tree that represents the morse tree given in the lab manual,
//where 0s are empty spaces
char string[] = {0, 'E', 'I', 'S', 'H', '5', '4', 'V', 0, '3', 'U', 'F',
0, 0, 0, 0, '2', 'A', 'R', 'L', 0, 0, 0, 0, 0, 'W', 'P', 0, 0, 'J', 0, '1',
'T', 'N', 'D', 'B', '6', 0, 'X', 0, 0, 'K', 'C', 0, 0, 'Y', 0, 0, 'M', 'G',
'Z', '7', 0, 'Q', 0, 0, 'O', 0, '8', 0, 0, '9', '0'}; 
Node *treestring;
Node *savetreestring = NULL;

//morse event checking enum for state
typedef enum {
    WAITING, DOT, DASH, INTER_LETTER
} morsecheckingevent;
// **** Declare any function prototypes here ****

//initializes the morse tree
int MorseInit(void) {
    treestring = TreeCreate(6, string);
    savetreestring = treestring;
    return (treestring) ? (SUCCESS) : (STANDARD_ERROR);
}

char MorseDecode(MorseChar in) {
     if (in == MORSE_CHAR_DOT) {
        treestring = treestring->leftChild;
    } else if (in == MORSE_CHAR_DASH) {
        treestring = treestring->rightChild;
    } else if (in == MORSE_CHAR_END_OF_CHAR) {
        return (treestring->data);
    } else if (in == MORSE_CHAR_DECODE_RESET) {
        treestring = savetreestring;
        return SUCCESS;
    } else if (treestring == NULL){
        return STANDARD_ERROR;
    }
    return in;
}

MorseEvent MorseCheckEvents(void) {
    int c = 0;
    switch (ButtonsCheckEvents()) {
    case WAITING:
        if (BUTTON_EVENT_4DOWN){
        c = 0;
        //return BUTTON_EVENT_NONE;
        }
        break;
    case DOT:
        if (BUTTON_EVENT_4UP) {
            c = 0;
            return MORSE_EVENT_DOT;
        } else { 
            //Counter >= MORSE_EVENT_LENGTH_DOWN_DOT;
            case DASH: 
                if (BUTTON_EVENT_4UP) {
                    c = 0;
                    return MORSE_EVENT_DASH;
                }
        }
        break;
    case INTER_LETTER:
        if (BUTTON_EVENT_4DOWN) {
            if (c >= MORSE_EVENT_LENGTH_UP_INTER_LETTER) {
                return MORSE_EVENT_INTER_LETTER;
                c = 0;
            } else {
                return MORSE_EVENT_NONE;
                c = 0;
            }
        } else if (c >= MORSE_EVENT_LENGTH_UP_INTER_LETTER) {
            return MORSE_EVENT_INTER_WORD;
            }
        break;
    } return c;

}    
