//Lucas Chambliss, lchambli@ucsc.edu
// **** Include libraries here ****
// Standard C libraries
//Battle Boats Lab Partner Alex Martin-Ginnold

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries
#include "Tree.h"
#include "Ascii.h"
#include "Morse.h"
#include "Oled.h"
#include "OledDriver.h"

// **** Set any macros or preprocessor directives here ****
// Specify a bit mask for setting/clearing the pin corresponding to BTN4. Should only be used when
// unit testing the Morse event checker.

// **** Declare any data types here ****

// **** Define any module-level, global, or external variables here ****

// **** Declare any function prototypes here ****
Node *TreeCreate(int level, const char *data){
    Node *new = malloc(sizeof(Node));
    new->data = *data;
    new->leftChild = (level - 1) ? (TreeCreate(level-1, data)) : NULL;
    new->rightChild = (level - 1) ? (TreeCreate(level - 1, data )) : NULL;
    return new;
}

