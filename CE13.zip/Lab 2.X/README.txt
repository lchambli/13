Lucas Chambliss

24 hours total

I ended up having issues with curly brackets {} being misplaced, and with floating point declarations, but I got a lot of help from TAs in the Wednesday section. Doing the binary conversion was never explicitly explained in the lab manual, and when I looked up how to do it, I only found really complicated code that was too in depth to not be considered copied if I was to implement it (which I’m not going to of course because that is academic dishonesty). So I left that part incomplete. Otherwise the program compiles and it was a really good assignment that helped with understanding previous syntax issues i had had.
