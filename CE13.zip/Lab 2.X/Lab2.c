// **** Include libraries here ****
// Standard libraries
#include <stdio.h>
#include <math.h>

//CMPE13 Support Library
#include "BOARD.h"

// Microchip libraries
#include <xc.h>
#include <plib.h>

// User libraries


// **** Set macros and preprocessor directives ****

// **** Define global, module-level, or external variables here ****
#define pi 3.14
// **** Declare function prototypes ****
//double Round(double operand);
double AbsoluteValue(double x1);
double FahrenheitToCelsius(double x1);
double CelsiusToFahrenheit(double x1);
double Tangent(double x1);
double Average(double x1, double x2);
// If this code is used for testing, rename main to something we can call from our testing code.
#ifndef LAB2_TESTING

int main(void)
{
    BOARD_Init();
#else

int their_main(void)
{
#endif // LAB2_TESTING

    /******************************************************************************
     * Your code goes in between this comment and the following one with asterisks.
     *****************************************************************************/
    printf("Hello! Welcome to Lucas's Calculator!\n");
    char c, x;
    char operator;
    double x1, x2, answer; //use input points x1 and x2 for operations from user
    operator = 0;
    printf("Enter a mathematical operation to perform (*,/,+,-,v,a,c,f,t):\n");
    scanf("%c", &c);
    if (c == '*' || c == '/' || c == '+' || c == '-' || c == 'v' || c == 'a' || c == 'c' || c == 'f' || c == 't') {
        operator = 1;}
    
    if (operator == 1){
        printf("Enter the first operand:\n");
        scanf("%lf%c", &x1, &x);
        
        if (c == '*' || c == '/' || c == '+' || c == '-' || c == 'v'){
            printf ("Enter the second operand:\n");
            scanf ("%lf%c", &x2, &x);
            if (c == '*'){
                answer = (x1*x2);
            } 
            else if (c == '/'){
                answer = (x1/x2);
            }
            else if (c == '+'){
                answer = (x1+x2);
            }
            else if (c == '-'){
                answer = (x1-x2);
            }
            else if (c == 'v'){
                answer = Average (x1, x2); 
            }
         
        printf ("answer=%f", answer);
        }else if (c == 'a' || c == 'c' || c == 'f' || c == 't'){
            if (c == 'a'){
                answer = AbsoluteValue (x1);
            }
            else if (c == 'c'){
                answer = CelsiusToFahrenheit (x1);
            }
            else if (c == 'f'){
                answer = FahrenheitToCelsius (x1);
            }
            else if (c == 't'){
                answer = Tangent(x1);
            }
        } printf ("answer=%f", answer);   
    
    }else {
        printf("Error, not a valid operator\n");
    }
            


    /******************************************************************************
     * Your code goes in between this comment and the preceding one with asterisks
     *****************************************************************************/
 while (1);
}

/********************************************************************************
 * Define the Absolute Value function here.
 ********************************************************************************/
double AbsoluteValue(double x1)
{if (x1 < 0){
        x1 = (x1)*(-1);}
return x1;
}
/*********************************************************************************
 * Define the Fahrenheit to Celsius function here.
 ********************************************************************************/
double FahrenheitToCelsius(double x1)
{return (5.0/9.0)*(x1-32);
}
/*********************************************************************************
 * Define the Celsius to Fahrenheit function here.
 ********************************************************************************/
double CelsiusToFahrenheit(double x1)
{return (9.0/5.0)*(x1)+32;
}
/********************************************************************************
 * Define the Average function here.
 *******************************************************************************/
double Average(double x1, double x2)
{return (x1+x2)/2.0;
}
/*********************************************************************************
 * Define the Tangent function that takes input in degrees (Note: Your tangent 
 * function relies on a call from the tangent function of math.h which uses 
 * radians).
 ********************************************************************************/
double Tangent(double x1)
{double degrees = tan(x1);
degrees *= pi/180;
}
/*********************************************************************************
 * Define the Round function here.
 * In order to receive the extra credit your calculator MUST ALSO CORRECTLY utilize
 * this function.
 ********************************************************************************/
//double Round(double operand)
//{
//    return operand;
//}

